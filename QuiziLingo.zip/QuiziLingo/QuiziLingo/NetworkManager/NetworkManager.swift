import Foundation

final class NetworkManager {
    
    private let baseURL = "https://parseapi.back4app.com"
    private let applicationId = "3ABoU5G6Ia3VkffPilBYkB6gw5aTisYUtR9sjddx"
    private let restApiKey = "iJ6SnaAXYLFlju9tbGiiE4UKq3hs6OICLlVcombw"

    // MARK: - Login
    func login(username: String, password: String, completion: @escaping (Result<UserSession, Error>) -> Void) {
        guard let url = URL(string: "\(baseURL)/login?username=\(username)&password=\(password)") else {
            completion(.failure(NSError(domain: "Invalid login URL", code: 0)))
            return
        }
        
        var request = URLRequest(url: url)
        request.setValue(applicationId, forHTTPHeaderField: "X-Parse-Application-Id")
        request.setValue(restApiKey, forHTTPHeaderField: "X-Parse-REST-API-Key")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                DispatchQueue.main.async { completion(.failure(error)) }
                return
            }
            
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "No data received", code: 0)))
                }
                return
            }
            
            do {
                let session = try JSONDecoder().decode(UserSession.self, from: data)
                DispatchQueue.main.async {
                    completion(.success(session))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }.resume()
    }

    // MARK: - Fetch Lessons
    func fetchLessons(completion: @escaping (Result<[Lesson], Error>) -> Void) {
        guard let url = URL(string: "\(baseURL)/classes/Lesson") else {
            completion(.failure(NSError(domain: "Invalid lessons URL", code: 0)))
            return
        }

        var request = URLRequest(url: url)
        request.setValue(applicationId, forHTTPHeaderField: "X-Parse-Application-Id")
        request.setValue(restApiKey, forHTTPHeaderField: "X-Parse-REST-API-Key")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                DispatchQueue.main.async { completion(.failure(error)) }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    completion(.failure(NSError(domain: "No data received", code: 0)))
                }
                return
            }

            do {
                let decoded = try JSONDecoder().decode(LessonResponse.self, from: data)
                DispatchQueue.main.async {
                    completion(.success(decoded.results))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }.resume()
    }
}
