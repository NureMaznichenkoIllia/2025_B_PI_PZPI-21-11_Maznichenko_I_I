//
//  DonatChartView.swift
//  T-Fin
//
//  Created by m223 on 22.10.2024.
//

import UIKit

class DountChartView: UIView {

    var activeTargetsCount: Int = 0 {
        didSet { setNeedsDisplay() }
    }
    
    var archivedTargetsCount: Int = 0 {
        didSet { setNeedsDisplay() }
    }
    
    override func draw(_ rect: CGRect) {
        guard activeTargetsCount + archivedTargetsCount > 0 else { return }
        
        let total = activeTargetsCount + archivedTargetsCount
        let activePercentage = CGFloat(activeTargetsCount) / CGFloat(total)
        let archivedPercentage = CGFloat(archivedTargetsCount) / CGFloat(total)
        
        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        let radius = min(bounds.width, bounds.height) / 2
        let innerRadius = radius * 0.6

        let context = UIGraphicsGetCurrentContext()
        
        context?.setFillColor(UIColor(red: 66/255, green: 179/255, blue: 189/255, alpha: 1.0).cgColor)
        context?.move(to: center)
        context?.addArc(center: center, radius: radius, startAngle: -CGFloat.pi / 2, endAngle: -CGFloat.pi / 2 + archivedPercentage * 2 * CGFloat.pi, clockwise: false)
        context?.addArc(center: center, radius: innerRadius, startAngle: -CGFloat.pi / 2 + archivedPercentage * 2 * CGFloat.pi, endAngle: -CGFloat.pi / 2, clockwise: true)
        context?.closePath()
        context?.fillPath()

        context?.setFillColor(UIColor(red: 210/255, green: 41/255, blue: 159/255, alpha: 1.0).cgColor)
        context?.move(to: center)
        context?.addArc(center: center, radius: radius, startAngle: -CGFloat.pi / 2 + archivedPercentage * 2 * CGFloat.pi, endAngle: -CGFloat.pi / 2 + 2 * CGFloat.pi, clockwise: false)
        context?.addArc(center: center, radius: innerRadius, startAngle: -CGFloat.pi / 2 + 2 * CGFloat.pi, endAngle: -CGFloat.pi / 2 + archivedPercentage * 2 * CGFloat.pi, clockwise: true)
        context?.closePath()
        context?.fillPath()
        
        self.backgroundColor = .clear
    }
}
