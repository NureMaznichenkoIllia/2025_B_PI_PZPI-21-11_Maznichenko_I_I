import UIKit

struct OnboardingStep {
    let imageName: String
    let sliderImageName: String
    let title: String
    let description: String
}

final class OnboardingVC: UIViewController {

    private let topImageView = UIImageView()
    private let sliderImageView = UIImageView()
    private let descriptionStack = UIStackView()
    private let nextButton = UIButton()
    private let loginButton = UIButton()

    private let titleLabel = UILabel()
    private let descriptionLabel = UILabel()

    private var steps: [OnboardingStep] = [
        OnboardingStep(
            imageName: "onboarding_image_1",
            sliderImageName: "slider_image_1",
            title: "Confidence in your words",
            description: "With conversation-based learning, you'll be talking from lesson one"
        ),
        OnboardingStep(
            imageName: "onboarding_image_2",
            sliderImageName: "slider_image_2",
            title: "Take your time to learn",
            description: "Develop a habit of learning and make it a part of your daily routine"
        ),
        OnboardingStep(
            imageName: "onboarding_image_3",
            sliderImageName: "slider_image_3",
            title: "The lessons you need to learn",
            description: "Using a variety of learning styles to learn and retain"
        )
    ]

    private var currentStepIndex = 0

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        setupViews()
        updateContent()
    }

    private func setupViews() {
        topImageView.contentMode = .scaleAspectFit
        topImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topImageView)
        
        sliderImageView.contentMode = .scaleAspectFit
        sliderImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sliderImageView)

        titleLabel.font = CustomFonts.FredokaMedium.font(size: 22)
        titleLabel.textColor = CustomColors.Basic.darkLighter
        titleLabel.textAlignment = .center
        titleLabel.numberOfLines = 0

        descriptionLabel.font = CustomFonts.FredokaRegular.font(size: 15)
        descriptionLabel.textColor = CustomColors.Basic.darkGray
        descriptionLabel.textAlignment = .center
        descriptionLabel.numberOfLines = 2
        descriptionLabel.lineBreakMode = .byWordWrapping

        descriptionStack.axis = .vertical
        descriptionStack.spacing = 8
        descriptionStack.distribution = .fillProportionally
        descriptionStack.addArrangedSubview(titleLabel)
        descriptionStack.addArrangedSubview(descriptionLabel)
        descriptionStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(descriptionStack)

        nextButton.setImage(UIImage(named: "next_button"), for: .normal)
        nextButton.addTarget(self, action: #selector(nextButtonTapped), for: .touchUpInside)
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nextButton)
        
        loginButton.setImage(UIImage(named: "regitst_login_button"), for: .normal)
        loginButton.addTarget(self, action: #selector(nextButtonTapped), for: .touchUpInside)
        loginButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(loginButton)

        setupLayouts()
    }

    private func setupLayouts() {
        NSLayoutConstraint.activate([
            topImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            topImageView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.64),
            
            sliderImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            sliderImageView.bottomAnchor.constraint(equalTo: titleLabel.topAnchor, constant: -50),

            descriptionStack.topAnchor.constraint(equalTo: topImageView.bottomAnchor),
            descriptionStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            descriptionStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            descriptionStack.bottomAnchor.constraint(equalTo: nextButton.topAnchor, constant: -60),

            nextButton.bottomAnchor.constraint(equalTo: loginButton.topAnchor, constant: -10),
            nextButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            nextButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            nextButton.heightAnchor.constraint(equalToConstant: 54),

            loginButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            loginButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loginButton.heightAnchor.constraint(equalToConstant: 54)
        ])

        let topOffset: CGFloat = view.frame.width <= 375 ? -80 : -40
        topImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: topOffset).isActive = true
    }

    private func updateContent() {
        let step = steps[currentStepIndex]
        topImageView.image = UIImage(named: step.imageName)
        sliderImageView.image = UIImage(named: step.sliderImageName)
        titleLabel.text = step.title
        descriptionLabel.text = step.description
    }

    @objc private func nextButtonTapped() {
        currentStepIndex += 1

        if currentStepIndex == 2 {
            nextButton.setImage(UIImage(named: "signup_button"), for: .normal)
            updateContent()
        } else if currentStepIndex < steps.count {
            updateContent()
        } else {
            let vc = RegistrationViewController()
            vc.isLoginFlow = false
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
