//
//  PlayVC.swift
//  QuiziLingo
//
//  Created by m223 on 17.06.2025.
//


import UIKit

class PlayVC: UIViewController {
    
    private let bottomPurpleView = UIView()

    private var cards: [CardModel]
    private var currentIndex = 0
    private var isShowingDefinition = true
    
    private let cardView = UIView()
    private let textLabel = UILabel()
    
    init(cards: [CardModel]) {
        self.cards = cards
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        navigationItem.hidesBackButton = true
        title = "Game"
        setupCardView()
        showCurrentCard()
        setupLayout()
        
        let closeButton = UIBarButtonItem(
            image: UIImage(systemName: "xmark")?.withRenderingMode(.alwaysTemplate),
            style: .plain,
            target: self,
            action: #selector(closeButtonTapped)
        )
        closeButton.tintColor = .white
        navigationItem.rightBarButtonItem = closeButton

    }
    
    @objc private func closeButtonTapped() {
        let alert = UIAlertController(
            title: "Are you sure you want to quit?",
            message: "Your progress will not be saved.",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Quit", style: .destructive, handler: { _ in
            self.navigationController?.popViewController(animated: true)
        }))
        
        present(alert, animated: true, completion: nil)
    }

    private func setupLayout() {
        bottomPurpleView.backgroundColor = CustomColors.Basic.purple65
        bottomPurpleView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomPurpleView)
        
        NSLayoutConstraint.activate([
            bottomPurpleView.topAnchor.constraint(equalTo: view.topAnchor),
            bottomPurpleView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            bottomPurpleView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomPurpleView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }
    
    private func setupCardView() {
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 16
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.2
        cardView.layer.shadowOffset = CGSize(width: 0, height: 4)
        cardView.layer.shadowRadius = 6
        
        textLabel.textAlignment = .center
        textLabel.numberOfLines = 0
        textLabel.font = CustomFonts.FredokaMedium.font(size: 20)
        textLabel.textColor = CustomColors.Basic.blue
        
        cardView.addSubview(textLabel)
        view.addSubview(cardView)
        
        cardView.translatesAutoresizingMaskIntoConstraints = false
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            cardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cardView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            cardView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            cardView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4),
            
            textLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            textLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -16),
            textLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            textLabel.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -16)
        ])
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(cardTapped))
        cardView.addGestureRecognizer(tap)
    }
    
    private func showCurrentCard() {
        guard currentIndex < cards.count else {
            textLabel.textColor = CustomColors.Basic.darkLighter
            textLabel.text = "You’ve finished the deck! 🎉"
            cardView.backgroundColor = CustomColors.Basic.green81

            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                let newTabBarController = TabBarController()
                if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                    if let window = scene.windows.first {
                        window.rootViewController = newTabBarController
                        window.makeKeyAndVisible()
                    }
                }
            }

            return
        }

        let card = cards[currentIndex]
        isShowingDefinition = true
        cardView.backgroundColor = .white
        textLabel.text = card.definition
    }

    
    @objc private func cardTapped() {
        guard currentIndex < cards.count else { return }
        
        let card = cards[currentIndex]
        
        UIView.transition(with: cardView, duration: 0.5, options: .transitionFlipFromRight, animations: {
            self.textLabel.text = self.isShowingDefinition ? card.term : card.definition
        }) { _ in
            if self.isShowingDefinition {
                self.isShowingDefinition = false

                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    self.currentIndex += 1
                    self.showCurrentCard()
                }
            }
        }
    }
}
