//
//  CardModel.swift
//  QuiziLingo
//
//  Created by m223 on 17.06.2025.
//


import Foundation

struct CardModel: Codable {
    var term: String
    var definition: String
}

struct AlbumModel: Codable {
    var id: UUID
    var title: String
    var cards: [CardModel]
    
    init(title: String, cards: [CardModel] = []) {
        self.id = UUID()
        self.title = title
        self.cards = cards
    }
}
