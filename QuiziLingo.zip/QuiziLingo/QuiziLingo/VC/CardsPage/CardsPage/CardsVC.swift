//
//  CardsVC.swift
//  QuiziLingo
//
//  Created by m223 on 17.06.2025.
//


import UIKit

class CardsVC: UIViewController {
    
    private let bottomPurpleView = UIView()

    private var albums: [AlbumModel] = []
    private let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 10
        layout.sectionInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.isPagingEnabled = false
        cv.showsVerticalScrollIndicator = true
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.backgroundColor = .clear
        return cv
    }()


    private let cellIdentifier = "AlbumCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Albums"
        view.backgroundColor = .white
        albums = AlbumStorage.shared.loadAlbums()
        setupLayout()
        setupCollectionView()
        setupNavBar()
    }
    
    func updateAlbum(_ updatedAlbum: AlbumModel?) {
        guard let updatedAlbum else { return }
        if let index = albums.firstIndex(where: { $0.id == updatedAlbum.id }) {
            albums[index] = updatedAlbum
            AlbumStorage.shared.saveAlbums(albums)
        }
    }
    
    @objc private func addAlbumTapped() {
        let alert = UIAlertController(title: "Create Album", message: "Enter album name", preferredStyle: .alert)
        
        alert.addTextField { textField in
            textField.placeholder = "Album Name"
        }
        
        let createAction = UIAlertAction(title: "Create", style: .default) { [weak self, weak alert] _ in
            guard let title = alert?.textFields?.first?.text, !title.isEmpty else { return }
            let album = AlbumModel(title: title)
            self?.albums.append(album)
            AlbumStorage.shared.saveAlbums(self?.albums ?? [])
            self?.collectionView.reloadData()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        alert.addAction(createAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true)
    }
    
    private func setupNavBar() {
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addAlbumTapped))
        addButton.tintColor = .white
        navigationItem.rightBarButtonItem = addButton

        let backImage = UIImage(named: "back_button")?.withRenderingMode(.alwaysOriginal)
        let backButton = UIBarButtonItem(image: backImage, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem = backButton
    }

    @objc private func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }

    private func setupLayout() {
        bottomPurpleView.backgroundColor = CustomColors.Basic.purple65
        bottomPurpleView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomPurpleView)
        
        NSLayoutConstraint.activate([
            bottomPurpleView.topAnchor.constraint(equalTo: view.topAnchor),
            bottomPurpleView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            bottomPurpleView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomPurpleView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }

    private func editAlbum(at indexPath: IndexPath) {
        let album = albums[indexPath.item]
        
        let alert = UIAlertController(title: "Edit Album", message: "Change album name", preferredStyle: .alert)
        
        alert.addTextField { textField in
            textField.text = album.title
            textField.placeholder = "New Album Name"
        }
        
        let saveAction = UIAlertAction(title: "Save", style: .default) { [weak self, weak alert] _ in
            guard let newTitle = alert?.textFields?.first?.text, !newTitle.isEmpty else { return }
            self?.albums[indexPath.item].title = newTitle
            AlbumStorage.shared.saveAlbums(self?.albums ?? [])
            self?.collectionView.reloadItems(at: [indexPath])
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true)
    }

    
    private func setupCollectionView() {
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(EmptyStateCell.self, forCellWithReuseIdentifier: EmptyStateCell.identifier)
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: cellIdentifier)
        view.addSubview(collectionView)
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }
    
    private func confirmDeleteAlbum(at indexPath: IndexPath) {
        let albumToDelete = albums[indexPath.item]

        let alert = UIAlertController(
            title: "Delete Album",
            message: "Are you sure you want to delete this album?",
            preferredStyle: .alert
        )

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { [weak self] _ in
            self?.albums.remove(at: indexPath.item)
            AlbumStorage.shared.saveAlbums(self?.albums ?? [])
            self?.collectionView.deleteItems(at: [indexPath])
        }))

        present(alert, animated: true)
    }

}

extension CardsVC: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return albums.isEmpty ? 1 : albums.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if albums.isEmpty {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: EmptyStateCell.identifier, for: indexPath) as! EmptyStateCell
            return cell
        }

        let album = albums[indexPath.item]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath)
        
        for sub in cell.contentView.subviews { sub.removeFromSuperview() }
        
        let label = UILabel(frame: cell.bounds)
        label.text = album.title
        label.textAlignment = .center
        
        if indexPath.item % 2 == 0 {
            cell.backgroundColor = .systemBlue
            label.textColor = .white
        } else {
            cell.backgroundColor = CustomColors.Basic.orange253
            label.textColor = CustomColors.Basic.darkLighter
        }
        
        cell.contentView.addSubview(label)
        
        cell.layer.cornerRadius = 12
        cell.layer.masksToBounds = true

        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout
        collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
    }

    
    func collectionView(_ collectionView: UICollectionView, layout
        collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {

        let width = collectionView.bounds.width - 16 * 2
        let height = width * 0.3
        
        return CGSize(width: width, height: height)
    }


    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard !albums.isEmpty else { return }

        let selectedAlbum = albums[indexPath.item]
        let detailVC = AlbumDetailVC(album: selectedAlbum)
        navigationController?.pushViewController(detailVC, animated: true)
    }

    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        guard !albums.isEmpty else { return nil }

        return UIContextMenuConfiguration(identifier: indexPath as NSIndexPath, previewProvider: nil) { _ in
            let editAction = UIAction(title: "Edit", image: UIImage(systemName: "pencil")) { [weak self] _ in
                self?.editAlbum(at: indexPath)
            }

            let deleteAction = UIAction(title: "Delete", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                self?.confirmDeleteAlbum(at: indexPath)
            }

            return UIMenu(title: "", children: [editAction, deleteAction])
        }
    }
}
