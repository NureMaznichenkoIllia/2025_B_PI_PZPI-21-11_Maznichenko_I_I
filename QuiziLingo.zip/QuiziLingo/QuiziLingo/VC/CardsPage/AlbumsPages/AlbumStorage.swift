//
//  AlbumStorage.swift
//  QuiziLingo
//
//  Created by m223 on 17.06.2025.
//


import Foundation

class AlbumStorage {
    static let shared = AlbumStorage()
    
    private let key = "saved_albums"
    private let defaults = UserDefaults.standard
    
    var albumsCount: Int {
        return loadAlbums().count
    }
    private init() {}
    
    func saveAlbums(_ albums: [AlbumModel]) {
        if let data = try? JSONEncoder().encode(albums) {
            defaults.set(data, forKey: key)
        }
    }
    
    func loadAlbums() -> [AlbumModel] {
        guard let data = defaults.data(forKey: key),
              let albums = try? JSONDecoder().decode([AlbumModel].self, from: data)
        else {
            return []
        }
        return albums
    }
}
