//
//  CreateAlbumVC.swift
//  QuiziLingo
//
//  Created by m223 on 17.06.2025.
//


import UIKit

class CreateAlbumVC: UIViewController {
    
    var onAlbumCreated: ((AlbumModel) -> Void)?
    
    private let titleField: UITextField = {
        let field = UITextField()
        field.placeholder = "Название альбома"
        field.borderStyle = .roundedRect
        return field
    }()
    
    private let createButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Создать", for: .normal)
        button.addTarget(self, action: #selector(createTapped), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Создание Альбома"
        view.backgroundColor = .systemBackground
        layoutUI()
    }
    
    private func layoutUI() {
        view.addSubview(titleField)
        view.addSubview(createButton)
        titleField.translatesAutoresizingMaskIntoConstraints = false
        createButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            titleField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleField.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            titleField.widthAnchor.constraint(equalToConstant: 250),
            createButton.topAnchor.constraint(equalTo: titleField.bottomAnchor, constant: 20),
            createButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    @objc private func createTapped() {
        guard let title = titleField.text, !title.isEmpty else { return }
        let album = AlbumModel(title: title)
        onAlbumCreated?(album)
        navigationController?.popViewController(animated: true)
    }
}
