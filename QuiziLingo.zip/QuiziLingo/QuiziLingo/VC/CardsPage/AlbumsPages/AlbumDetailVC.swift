import UIKit

class AlbumDetailVC: UIViewController {
    
    var album: AlbumModel
    private let tableView = UITableView()
    private let playButton = UIButton(type: .system)
    
    private let bottomPurpleView = UIView()

    init(album: AlbumModel) {
        self.album = album
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = album.title
        view.backgroundColor = .white
        setupTableView()
        setupLayout()
        setupAddButton()
        setupPlayButton()
        setupNavBar()
        updatePlayButtonState()
    }
    
    private func setupNavBar() {
        let backImage = UIImage(named: "back_button")?.withRenderingMode(.alwaysOriginal)
        let backButton = UIBarButtonItem(image: backImage, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem = backButton
    }

    @objc private func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }
    
    private func setupTableView() {
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cardCell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leftAnchor.constraint(equalTo: view.leftAnchor),
            tableView.rightAnchor.constraint(equalTo: view.rightAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -80)
        ])
    }
    
    private func setupLayout() {
        bottomPurpleView.backgroundColor = CustomColors.Basic.purple65
        bottomPurpleView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomPurpleView)
        
        NSLayoutConstraint.activate([
            bottomPurpleView.topAnchor.constraint(equalTo: view.topAnchor),
            bottomPurpleView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            bottomPurpleView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomPurpleView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }
    
    private func setupAddButton() {
        let addButton = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addCardTapped)
        )
        addButton.tintColor = .white
        navigationItem.rightBarButtonItem = addButton
    }
    
    private func setupPlayButton() {
        playButton.setTitle("Play", for: .normal)
        playButton.setTitleColor(.white, for: .normal)
        playButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        playButton.backgroundColor = .systemBlue
        playButton.layer.cornerRadius = 12
        playButton.addTarget(self, action: #selector(playTapped), for: .touchUpInside)
        playButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(playButton)
        
        NSLayoutConstraint.activate([
            playButton.heightAnchor.constraint(equalToConstant: 50),
            playButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            playButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            playButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16)
        ])
    }
    
    @objc private func playTapped() {
        if album.cards.isEmpty {
            let alert = UIAlertController(title: "No Cards", message: "Please add at least one card to play.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        } else {
            let playVC = PlayVC(cards: album.cards)
            navigationController?.pushViewController(playVC, animated: true)
        }
    }
    
    @objc private func addCardTapped() {
        let alert = UIAlertController(title: "New Card", message: "Enter the term and its definition", preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "Term" }
        alert.addTextField { $0.placeholder = "Definition" }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Add", style: .default, handler: { [weak self] _ in
            guard
                let term = alert.textFields?[0].text, !term.isEmpty,
                let definition = alert.textFields?[1].text, !definition.isEmpty
            else { return }

            let newCard = CardModel(term: term, definition: definition)
            self?.album.cards.append(newCard)

            if let nav = self?.navigationController,
               let cardsVC = nav.viewControllers.first(where: { $0 is CardsVC }) as? CardsVC {
                cardsVC.updateAlbum(self?.album)
            }

            self?.tableView.reloadData()
            self?.updatePlayButtonState()
        }))
        present(alert, animated: true)
    }
    
    private func updatePlayButtonState() {
        let hasCards = !album.cards.isEmpty
        playButton.alpha = hasCards ? 1.0 : 0.5
    }

}

extension AlbumDetailVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return album.cards.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let card = album.cards[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cardCell", for: indexPath)
        cell.textLabel?.text = "📘 \(card.term): \(card.definition)"
        cell.textLabel?.textColor = CustomColors.Basic.darkLighter
        cell.textLabel?.font = CustomFonts.FredokaRegular.font(size: 18)
        cell.backgroundColor = .clear
        return cell
    }
}
