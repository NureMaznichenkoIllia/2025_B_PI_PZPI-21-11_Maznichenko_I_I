import UIKit

class RegistrationViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    var isLoginFlow: Bool = false
    private var isFirstStep = true
    private let actionButton = UIButton()
    private let loginButton = UIButton()
    
    private let topStackView = UIStackView()
    private let imageView = UIImageView()
    private let messageLabel = UILabel()
    private let purpleBackgroundView = UIView()

    private var collectionView: UICollectionView!

    private var userInfoFields: [RegistrationField] = [
        RegistrationField(title: "First Name", placeholder: "Enter your first name"),
        RegistrationField(title: "Last Name", placeholder: "Enter your last name"),
        RegistrationField(title: "Email Address", placeholder: "Enter your email")
    ]

    private var credentialFields: [RegistrationField] = [
        RegistrationField(title: "Password", placeholder: "Enter your password"),
        RegistrationField(title: "Confirm Password", placeholder: "Re-enter your password")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTopStackView()
        setupCollectionView()
//        setupCustomBackButton()
        setupCustomTitle("Signup")
        setupLoginButton()
        setupActionButton()
        setupKeyboardDismissGesture()
        
        navigationItem.hidesBackButton = true
        
        setupPurpleBackground()
        view.backgroundColor = .white
    }
    
    private func setupKeyboardDismissGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
    }

    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }

    private func setupActionButton() {
        actionButton.setImage(UIImage(named: "continue_button"), for: .normal)
        actionButton.translatesAutoresizingMaskIntoConstraints = false
        actionButton.addTarget(self, action: #selector(actionButtonTapped), for: .touchUpInside)

        view.addSubview(actionButton)

        NSLayoutConstraint.activate([
            actionButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            actionButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            actionButton.bottomAnchor.constraint(equalTo: loginButton.topAnchor, constant: -10),
            actionButton.heightAnchor.constraint(equalToConstant: 56)
        ])
    }
    
    private func setupLoginButton() {
        loginButton.setImage(UIImage(named: "already_login_button"), for: .normal)
        loginButton.translatesAutoresizingMaskIntoConstraints = false
        loginButton.contentMode = .scaleAspectFit
        loginButton.addTarget(self, action: #selector(actionButtonTapped), for: .touchUpInside)

        view.addSubview(loginButton)

        NSLayoutConstraint.activate([
            loginButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loginButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            loginButton.heightAnchor.constraint(equalToConstant: 56)
        ])
    }
    
    private func setupCustomTitle(_ text: String) {
        let titleLabel = UILabel()
        titleLabel.text = text
        titleLabel.font = CustomFonts.FredokaMedium.font(size: 17)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        
        navigationItem.titleView = titleLabel
    }

    
    private func setupCustomBackButton() {
        let backButton = UIButton(type: .system)

        let image = UIImage(named: "back_button")?.withRenderingMode(.alwaysOriginal)
        backButton.setImage(image, for: .normal)

        backButton.addTarget(self, action: #selector(customBackTapped), for: .touchUpInside)

        let customItem = UIBarButtonItem(customView: backButton)
        navigationItem.leftBarButtonItem = customItem
    }

    
    private func setupTopStackView() {
        imageView.image = UIImage(named: "learn_at_home")
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false

        messageLabel.text = "Create an Account"
        messageLabel.textAlignment = .center
        messageLabel.font = CustomFonts.FredokaMedium.font(size: 22)
        messageLabel.numberOfLines = 0
        messageLabel.textColor = CustomColors.Basic.darkLighter
        messageLabel.translatesAutoresizingMaskIntoConstraints = false

        topStackView.axis = .vertical
        topStackView.spacing = 12
        topStackView.alignment = .center
        topStackView.translatesAutoresizingMaskIntoConstraints = false

        if isLoginFlow {
            topStackView.addArrangedSubview(imageView)
        }
        topStackView.addArrangedSubview(messageLabel)

        view.addSubview(topStackView)

        NSLayoutConstraint.activate([
            topStackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            topStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            topStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            imageView.heightAnchor.constraint(equalToConstant: isLoginFlow ? 120 : 0)
        ])
    }
    
    private func setupPurpleBackground() {
        purpleBackgroundView.backgroundColor = CustomColors.Basic.purple65
        purpleBackgroundView.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(purpleBackgroundView, at: 0)

        NSLayoutConstraint.activate([
            purpleBackgroundView.topAnchor.constraint(equalTo: view.topAnchor),
            purpleBackgroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            purpleBackgroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            purpleBackgroundView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
        ])
    }


    private func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.headerReferenceSize = CGSize(width: view.frame.width, height: 0)
        layout.minimumLineSpacing = 20
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 32, right: 16) // отступы по краям

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.alwaysBounceVertical = true
        collectionView.backgroundColor = .white

        collectionView.register(InputCell.self, forCellWithReuseIdentifier: InputCell.identifier)
        collectionView.register(HeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HeaderView.identifier)
        collectionView.register(UICollectionReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "EmptyHeader")

        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(collectionView)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: topStackView.bottomAnchor, constant: 12),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return isFirstStep ? userInfoFields.count : credentialFields.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let field = isFirstStep ? userInfoFields[indexPath.item] : credentialFields[indexPath.item]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: InputCell.identifier, for: indexPath) as! InputCell
        cell.configure(with: field)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader && indexPath.section == 10 {
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: HeaderView.identifier, for: indexPath) as! HeaderView
            header.configure()
            return header
        } else {
            return collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "EmptyHeader", for: indexPath)
        }
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let horizontalPadding: CGFloat = 48
        let width = collectionView.bounds.width - horizontalPadding
        return CGSize(width: width, height: 84)
    }
    
    @objc private func customBackTapped() {
        navigationController?.popViewController(animated: true)
    }
    
    @objc private func actionButtonTapped() {
        if validateCurrentStep() {
            if isFirstStep {
                isFirstStep = false
                collectionView.reloadData()
            } else {
                navigationController?.pushViewController(AccountSetupVC(), animated: true)
            }
        }
    }
    
    private func validateCurrentStep() -> Bool {
        let fields = isFirstStep ? userInfoFields : credentialFields
        var allValid = true

        for index in fields.indices {
            guard let cell = collectionView.cellForItem(at: IndexPath(item: index, section: 0)) as? InputCell else { continue }

            let text = cell.textField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

            if text.isEmpty {
                cell.setErrorState(true)
                allValid = false
            } else if isFirstStep && index == 2 && !isValidEmail(text) {
                cell.setErrorState(true)
                allValid = false
            } else {
                cell.setErrorState(false)
            }
        }

        if !allValid {
            let alert = UIAlertController(title: "Error", message: "Please fill in all required fields correctly.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }

        return allValid
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
        return predicate.evaluate(with: email)
    }



}
