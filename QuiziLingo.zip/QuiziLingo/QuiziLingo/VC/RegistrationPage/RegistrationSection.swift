//
//  RegistrationSection.swift
//  QuiziLingo
//
//  Created by m223 on 08.05.2025.
//

import Foundation

enum RegistrationSection: Int, CaseIterable {
    case userInfo
    case credentials
}

struct RegistrationField {
    let title: String
    let placeholder: String
    var text: String?
}
