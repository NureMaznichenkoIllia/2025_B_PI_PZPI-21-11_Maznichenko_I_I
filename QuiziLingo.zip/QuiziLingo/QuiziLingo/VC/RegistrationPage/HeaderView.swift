//
//  HeaderView.swift
//  QuiziLingo
//
//  Created by m223 on 08.05.2025.
//

import UIKit


class HeaderView: UICollectionReusableView {
    static let identifier = "HeaderView"

    private let imageView = UIImageView()
    private let subtitleLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(imageView)
        addSubview(subtitleLabel)
        // Настройка layout
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure() {
        imageView.image = UIImage(named: "learn_at_home")
        subtitleLabel.text = "For free, join now and start learning"
    }
}
