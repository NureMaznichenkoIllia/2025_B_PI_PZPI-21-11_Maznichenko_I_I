import UIKit

class InputCell: UICollectionViewCell {
    static let identifier = "InputCell"

    private let titleLabel = UILabel()
    let textField = UITextField()

    override init(frame: CGRect) {
        super.init(frame: frame)

        titleLabel.textColor = CustomColors.Basic.darkLighter
        titleLabel.font = CustomFonts.FredokaRegular.font(size: 15)

        textField.layer.cornerRadius = 16
        textField.font = CustomFonts.FredokaRegular.font(size: 15)
        textField.backgroundColor = CustomColors.Basic.gray05
        textField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 0))
        textField.leftViewMode = .always
        textField.textColor = CustomColors.Basic.darkLighter

        contentView.addSubview(titleLabel)
        contentView.addSubview(textField)

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        textField.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            titleLabel.bottomAnchor.constraint(equalTo: textField.topAnchor, constant: -4),
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 4),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -4),

            textField.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            textField.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            textField.heightAnchor.constraint(equalToConstant: 56),
            textField.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -2)
        ])

        contentView.backgroundColor = .clear
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(with field: RegistrationField) {
        titleLabel.text = field.title
        textField.text = field.text

        textField.attributedPlaceholder = NSAttributedString(
            string: field.placeholder,
            attributes: [
                .foregroundColor: CustomColors.Basic.darkLighter.withAlphaComponent(0.5),
                .font: CustomFonts.FredokaRegular.font(size: 15)
            ]
        )
    }
    
    func setErrorState(_ isError: Bool) {
        textField.layer.borderWidth = isError ? 1.5 : 0
        textField.layer.borderColor = isError ? UIColor.red.cgColor : UIColor.clear.cgColor
    }
}
