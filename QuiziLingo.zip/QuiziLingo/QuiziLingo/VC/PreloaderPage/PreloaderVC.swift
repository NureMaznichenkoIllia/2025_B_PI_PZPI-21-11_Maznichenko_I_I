import UIKit
import RxSwift

final class PreloaderVC: UIViewController {

    private let appImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "app_logo"))
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()

    private let disposeBag = DisposeBag()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = CustomColors.Basic.purple65
        setupLayout()
        
        Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(showNextScreen), userInfo: nil, repeats: false)
    }

    private func setupLayout() {
        view.addSubview(appImageView)

        NSLayoutConstraint.activate([
            appImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            appImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            
        ])
    }

    @objc func showNextScreen() {
        let flagOfComplainedOnboarding = UserDefaults.standard.bool(forKey: "OnboardingCompleted")
        
        if flagOfComplainedOnboarding {
            showMainViewController()
        } else {
            let nextScreenVC = OnboardingVC()
            nextScreenVC.navigationItem.hidesBackButton = true
            navigationController?.pushViewController(nextScreenVC, animated: true)
        }
    }

    private func showMainViewController() {
        let newTabBarController = TabBarController()
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            if let window = scene.windows.first {
                window.rootViewController = newTabBarController
            }
        }
    }
}
