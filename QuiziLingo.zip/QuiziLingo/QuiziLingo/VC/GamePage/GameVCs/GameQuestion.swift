//
//  GameQuestion.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//

import UIKit
import Foundation

struct GameQuestion {
    let id: Int
    let type: GameType
    let prompt: String
    let image: UIImage?
    let choices: [(emoji: String, text: String)]
    let correctAnswer: String
    let subtitle: String?
}

