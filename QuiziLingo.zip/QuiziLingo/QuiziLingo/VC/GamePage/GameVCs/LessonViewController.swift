//
//  LessonViewController.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//

import UIKit
import Foundation

class LessonViewController: UIViewController {

    private var questions: [GameQuestion] = []
    private var currentIndex = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        navigationItem.hidesBackButton = true
        questions = loadQuestions()
        showCurrentQuestion()
    }

    private func showCurrentQuestion() {
        guard currentIndex < questions.count else {
            showLessonCompletion()
            return
        }

        let question = questions[currentIndex]
        let vc: UIViewController

        switch question.type {
        case .selectImage:
            let imageVC = GameViewController()
            imageVC.totalSteps = questions.count
            imageVC.currentStep = currentIndex + 1
            imageVC.configure(with: question)
            imageVC.onNext = goToNext
            vc = imageVC

        case .guessMeaning:
            let meaningVC = GuessMeaningViewController()
            meaningVC.configure(with: question)
            meaningVC.onNext = goToNext
            vc = meaningVC
        }

        transition(to: vc)
    }

    private func transition(to newVC: UIViewController) {
        if let current = children.first {
            current.willMove(toParent: nil)
            current.view.removeFromSuperview()
            current.removeFromParent()
        }

        addChild(newVC)
        newVC.view.frame = view.bounds
        view.addSubview(newVC.view)
        newVC.didMove(toParent: self)
    }

    private func goToNext() {
        currentIndex += 1
        showCurrentQuestion()
    }

    private func loadQuestions() -> [GameQuestion] {
        return [
            GameQuestion(
                id: 1,
                type: .selectImage,
                prompt: "man",
                image: nil,
                choices: [("👨", "Man"), ("👩", "Woman"), ("👧", "Girl"), ("👦", "Boy")],
                correctAnswer: "Man",
                subtitle: "adult male"
            ),
            GameQuestion(
                id: 2,
                type: .selectImage,
                prompt: "auto",
                image: nil,
                choices: [("🚲", "Bicycle"), ("🚗", "Car"), ("🛴", "Scooter"), ("🚌", "Bus")],
                correctAnswer: "Car",
                subtitle: "a four-wheeled vehicle"
            ),
            GameQuestion(
                id: 3,
                type: .selectImage,
                prompt: "appel",
                image: nil,
                choices: [("🍎", "Apple"), ("🍌", "Banana"), ("🍇", "Grapes"), ("🍓", "Strawberry")],
                correctAnswer: "Apple",
                subtitle: "a red fruit"
            ),
            GameQuestion(
                id: 4,
                type: .selectImage,
                prompt: "hond",
                image: nil,
                choices: [("🐱", "Cat"), ("🐶", "Dog"), ("🐭", "Mouse"), ("🦊", "Fox")],
                correctAnswer: "Dog",
                subtitle: "man's best friend"
            ),
            GameQuestion(
                id: 5,
                type: .selectImage,
                prompt: "school",
                image: nil,
                choices: [("🏠", "House"), ("🏫", "School"), ("🏥", "Hospital"), ("🏛️", "Museum")],
                correctAnswer: "School",
                subtitle: "place of learning"
            ),
            GameQuestion(
                id: 6,
                type: .selectImage,
                prompt: "blij",
                image: nil,
                choices: [("😢", "Sad"), ("😊", "Happy"), ("😡", "Angry"), ("😐", "Neutral")],
                correctAnswer: "Happy",
                subtitle: "feeling joy"
            )
        ]
    }




    private func showLessonCompletion() {
        let congratsVC = CongratsViewController()
        congratsVC.hidesBottomBarWhenPushed = true
        congratsVC.navigationItem.hidesBackButton = true
        navigationController?.pushViewController(congratsVC, animated: true)
    }
}
