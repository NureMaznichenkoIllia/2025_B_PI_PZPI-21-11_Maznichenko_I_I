//
//  GuessMeaningViewController.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//

import UIKit
import Foundation

class GuessMeaningViewController: UIViewController {
    
    private let emojiImageView = UIImageView()
    private let optionStack = UIStackView()
    private let feedbackView = UILabel()
    private let nextButton = UIButton(type: .system)
    
    var onNext: (() -> Void)?
    private var correctAnswer: String = ""
    
    func configure(with question: GameQuestion) {
        emojiImageView.image = question.image
        correctAnswer = question.correctAnswer
        
        for choice in question.choices {
            let button = UIButton(type: .system)
            button.setTitle(choice.text, for: .normal) // ✅ используем только текст
            button.addTarget(self, action: #selector(choiceTapped(_:)), for: .touchUpInside)
            optionStack.addArrangedSubview(button)
        }

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        view.backgroundColor = .white
        emojiImageView.contentMode = .scaleAspectFit
        
        optionStack.axis = .vertical
        optionStack.spacing = 12
        optionStack.alignment = .fill

        nextButton.setTitle("Next", for: .normal)
        nextButton.addTarget(self, action: #selector(nextTapped), for: .touchUpInside)
        nextButton.isHidden = true

        feedbackView.textAlignment = .center
        feedbackView.isHidden = true

        let stack = UIStackView(arrangedSubviews: [emojiImageView, optionStack, feedbackView, nextButton])
        stack.axis = .vertical
        stack.spacing = 20
        stack.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            emojiImageView.heightAnchor.constraint(equalToConstant: 150)
        ])
    }

    @objc private func choiceTapped(_ sender: UIButton) {
        let selected = sender.title(for: .normal)
        let isCorrect = selected == correctAnswer
        feedbackView.text = isCorrect ? "Correct!" : "Try again"
        feedbackView.textColor = isCorrect ? CustomColors.Basic.green81 : .systemRed
        feedbackView.isHidden = false
        nextButton.isHidden = !isCorrect
    }

    @objc private func nextTapped() {
        onNext?()
    }
}
