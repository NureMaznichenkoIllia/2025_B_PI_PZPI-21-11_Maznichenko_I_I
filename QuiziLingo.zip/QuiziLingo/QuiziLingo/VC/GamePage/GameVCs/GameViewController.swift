import UIKit

class GameViewController: UIViewController {

    // MARK: - NavBar & Progress
    private let navBar = UIView()
    private let backButton = UIButton(type: .system)
    private let closeButton = UIButton(type: .system)
    private let progressView = UIProgressView(progressViewStyle: .default)
    private let progressLabel = UILabel()

    var totalSteps = 6
    var currentStep = 0 {
        didSet {
            updateProgress()
        }
    }

    // MARK: - UI
    private let instructionLabel = UILabel()
    private let soundButton = UIButton(type: .system)
    private let imageView = UIImageView()
    private let underlinedLabel = UILabel()
    private let gridContainer = UIStackView()
    private let submitButton = UIButton(type: .system)

    private var selectedButton: UIButton?
    private var optionButtons: [UIButton] = []

    // MARK: - Data
    private var correctAnswer: String = ""
    private var selectedAnswer: String?
    var onNext: (() -> Void)?

    func configure(with question: GameQuestion) {
        underlinedLabel.attributedText = underlineDashed(question.subtitle ?? "")
        imageView.image = UIImage(named: "load_image_word")
        correctAnswer = question.correctAnswer

        // Remove old buttons
        optionButtons.forEach { $0.removeFromSuperview() }
        optionButtons = []

        for (index, choice) in question.choices.enumerated() {
            let button = createOptionButton(title: choice.text, emoji: choice.emoji, tag: index)
            optionButtons.append(button)
        }

        let firstRow = UIStackView(arrangedSubviews: [optionButtons[0], optionButtons[1]])
        let secondRow = UIStackView(arrangedSubviews: [optionButtons[2], optionButtons[3]])
        for row in [firstRow, secondRow] {
            row.axis = .horizontal
            row.spacing = 16
            row.distribution = .fillEqually
        }

        gridContainer.arrangedSubviews.forEach { $0.removeFromSuperview() }
        gridContainer.addArrangedSubview(firstRow)
        gridContainer.addArrangedSubview(secondRow)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupTopBarView()
        updateProgress()

        navigationItem.hidesBackButton = true
    }
    
    private func updateProgress() {
        let progress = Float(currentStep - 1) / Float(totalSteps)
        progressView.setProgress(progress, animated: false)
        progressLabel.text = "\(currentStep)/\(totalSteps)"
    }

    
    private func setupTopBarView() {
        let topBar = UIView()
        topBar.backgroundColor = CustomColors.Basic.purple65
        topBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topBar)

        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.heightAnchor.constraint(equalToConstant: 120)
        ])

        backButton.setImage(UIImage(systemName: "arrow.left"), for: .normal)
        backButton.tintColor = .white
        backButton.addTarget(self, action: #selector(backTapped), for: .touchUpInside)

        closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeButton.tintColor = .white
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)

        progressView.trackTintColor = .white
        progressView.progressTintColor = CustomColors.Basic.blue
        progressView.layer.cornerRadius = 5

        progressLabel.font = CustomFonts.FredokaMedium.font(size: 14)
        progressLabel.textColor = .white
        progressLabel.textAlignment = .center

        [backButton, closeButton, progressView, progressLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            topBar.addSubview($0)
        }

        NSLayoutConstraint.activate([
            backButton.leadingAnchor.constraint(equalTo: topBar.leadingAnchor, constant: 16),
            backButton.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -20),

            closeButton.trailingAnchor.constraint(equalTo: topBar.trailingAnchor, constant: -16),
            closeButton.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -20),

            progressView.centerXAnchor.constraint(equalTo: topBar.centerXAnchor),
            progressView.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -30),
            progressView.widthAnchor.constraint(equalTo: topBar.widthAnchor, multiplier: 0.6),
            progressView.heightAnchor.constraint(equalToConstant: 10),

            progressLabel.centerXAnchor.constraint(equalTo: topBar.centerXAnchor),
            progressLabel.topAnchor.constraint(equalTo: progressView.bottomAnchor, constant: 4)
        ])
    }

    
    @objc private func backTapped() {
        navigationController?.popViewController(animated: true)
    }

    @objc private func closeTapped() {
        let alert = UIAlertController(title: "Do you want finish the lesson",
                                      message: nil,
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Finish", style: .destructive) { _ in
            self.navigationController?.popToRootViewController(animated: true)
        })
        present(alert, animated: true)
    }



    private func setupUI() {
        view.backgroundColor = .white

        instructionLabel.text = "Select the correct image"
        instructionLabel.font = CustomFonts.FredokaMedium.font(size: 24)
        instructionLabel.textColor = CustomColors.Basic.darkLighter
        instructionLabel.textAlignment = .left

        soundButton.setImage(UIImage(systemName: "speaker.wave.2.fill"), for: .normal)
        soundButton.tintColor = .black
        soundButton.addTarget(self, action: #selector(playSound), for: .touchUpInside)
        soundButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        soundButton.heightAnchor.constraint(equalToConstant: 40).isActive = true

        imageView.contentMode = .scaleAspectFit
        imageView.widthAnchor.constraint(equalToConstant: 40).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: 40).isActive = true

        underlinedLabel.font = CustomFonts.FredokaMedium.font(size: 20)
        underlinedLabel.textColor = CustomColors.Basic.darkLighter
//        underlinedLabel.attributedText = underlineDashed("______")

        let horizontalStack = UIStackView(arrangedSubviews: [soundButton, underlinedLabel])
        horizontalStack.axis = .horizontal
        horizontalStack.spacing = 8
        horizontalStack.alignment = .leading
        horizontalStack.distribution = .fillProportionally

        gridContainer.axis = .vertical
        gridContainer.spacing = 16
        gridContainer.distribution = .fillEqually

        submitButton.translatesAutoresizingMaskIntoConstraints = false
        submitButton.setTitle("Submit", for: .normal)
        submitButton.setTitleColor(.white, for: .normal)
        submitButton.backgroundColor = UIColor.systemBlue
        submitButton.titleLabel?.font = CustomFonts.FredokaMedium.font(size: 20)
        submitButton.layer.cornerRadius = 12
        submitButton.addTarget(self, action: #selector(submitTapped), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [
            instructionLabel,
            horizontalStack,
            gridContainer
        ])
        stack.axis = .vertical
        stack.spacing = 24
        stack.alignment = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stack)
        view.addSubview(submitButton)

        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 36),
            
            submitButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            submitButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            submitButton.heightAnchor.constraint(equalToConstant: 54),
            submitButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10),
        ])
    }

    private func emojiToImage(_ emoji: String, size: CGFloat = 60) -> UIImage? {
        let label = UILabel()
        label.text = emoji
        label.font = UIFont.systemFont(ofSize: size)
        label.textAlignment = .center
        label.backgroundColor = .clear
        label.frame = CGRect(x: 0, y: 0, width: size, height: size)

        UIGraphicsBeginImageContextWithOptions(label.bounds.size, false, 0)
        guard let context = UIGraphicsGetCurrentContext() else { return nil }
        label.layer.render(in: context)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img
    }

    private func createOptionButton(title: String, emoji: String, tag: Int) -> UIButton {
        let button = UIButton(type: .system)
        button.backgroundColor = .clear
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 2
        button.layer.borderColor = UIColor.lightGray.cgColor
        button.tag = tag
        button.accessibilityIdentifier = title

        let imageView = UIImageView(image: emojiToImage(emoji))
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.heightAnchor.constraint(equalToConstant: 40).isActive = true

        let label = UILabel()
        label.text = title
        label.textAlignment = .center
        label.font = CustomFonts.FredokaMedium.font(size: 16)
        label.textColor = .black

        let stack = UIStackView(arrangedSubviews: [imageView, label])
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false

        button.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: button.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: button.centerYAnchor)
        ])

        button.heightAnchor.constraint(equalToConstant: 160).isActive = true
        button.addTarget(self, action: #selector(optionTapped(_:)), for: .touchUpInside)
        return button
    }

    private func underlineDashed(_ text: String) -> NSAttributedString {
        let attributes: [NSAttributedString.Key: Any] = [
            .underlineStyle: NSUnderlineStyle.patternDash.rawValue | NSUnderlineStyle.single.rawValue
        ]
        return NSAttributedString(string: text, attributes: attributes)
    }

    @objc private func playSound() {
        print("🔊 Playing sound...")
    }

    @objc private func optionTapped(_ sender: UIButton) {
        selectedButton?.layer.borderWidth = 0
        selectedButton = sender
        sender.layer.borderWidth = 2
        sender.layer.borderColor = UIColor.systemBlue.cgColor
        selectedAnswer = sender.accessibilityIdentifier // ✅ сохраняем корректно
    }

    @objc private func submitTapped() {
        guard let selected = selectedAnswer else { return }
        let isCorrect = selected == correctAnswer

        selectedButton?.layer.borderColor = UIColor.clear.cgColor
        selectedButton?.backgroundColor = isCorrect ? CustomColors.Basic.green81 : .systemRed

        submitButton.setTitle(isCorrect ? "Correct ✅" : "Wrong ❌", for: .normal)
        submitButton.backgroundColor = isCorrect ? CustomColors.Basic.green81 : .systemRed

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            self.onNext?()
        }
    }
}
