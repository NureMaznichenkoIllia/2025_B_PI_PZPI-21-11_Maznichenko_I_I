//
//  GameType.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//

import UIKit
import Foundation

enum GameType {
    case selectImage
    case guessMeaning
}
