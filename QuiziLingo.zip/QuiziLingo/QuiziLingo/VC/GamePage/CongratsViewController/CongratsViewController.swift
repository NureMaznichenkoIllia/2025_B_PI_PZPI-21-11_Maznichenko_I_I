//
//  CongratsViewController.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//


import UIKit

class CongratsViewController: UIViewController {

    private let backgroundView = UIView()
    private let contentView = UIView()

    private let imageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "congrats_icon"))
        imageView.contentMode = .scaleAspectFit
        imageView.heightAnchor.constraint(equalToConstant: 140).isActive = true
        return imageView
    }()

    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Lesson Completed"
        label.font = CustomFonts.FredokaMedium.font(size: 28)
        label.textColor = CustomColors.Basic.darkLighter
        label.textAlignment = .center
        return label
    }()

    private let subtitleLabel: UILabel = {
        let label = UILabel()
        label.text = "You have completed a new lesson in English"
        label.font = CustomFonts.FredokaRegular.font(size: 16)
        label.textColor = .gray
        label.textAlignment = .center
        label.numberOfLines = 2
        return label
    }()
    
    private let homeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Back to Home", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = CustomColors.Basic.blue
        button.titleLabel?.font = CustomFonts.FredokaMedium.font(size: 18)
        button.layer.cornerRadius = 12
        button.heightAnchor.constraint(equalToConstant: 54).isActive = true
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(nil, action: #selector(backToHomeTapped), for: .touchUpInside)
        return button
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupLayout()
        navigationItem.hidesBackButton = true
        incrementLessonsCompleted()
    }

    private func incrementLessonsCompleted() {
        let defaults = UserDefaults.standard
        let current = defaults.integer(forKey: "completed_english_lessons")
        defaults.set(current + 1, forKey: "completed_english_lessons")
    }
    
    private func setupLayout() {
        view.backgroundColor = CustomColors.Basic.purple65

        backgroundView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        contentView.backgroundColor = .white
        contentView.layer.cornerRadius = 24
        contentView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        view.addSubview(backgroundView)
        view.addSubview(contentView)

        NSLayoutConstraint.activate([
            backgroundView.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            backgroundView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            contentView.topAnchor.constraint(equalTo: view.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        // Stack
        let stack = UIStackView(arrangedSubviews: [imageView, titleLabel, subtitleLabel])
        stack.axis = .vertical
        stack.spacing = 20
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(stack)
        contentView.addSubview(homeButton)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 32),
            stack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -32),
            
            homeButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 24),
            homeButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -24),
            homeButton.bottomAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.bottomAnchor, constant: -20)

        ])
    }
    
    @objc private func backToHomeTapped() {
        let newTabBarController = TabBarController()
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            if let window = scene.windows.first {
                window.rootViewController = newTabBarController
            }
        }
    }
}
