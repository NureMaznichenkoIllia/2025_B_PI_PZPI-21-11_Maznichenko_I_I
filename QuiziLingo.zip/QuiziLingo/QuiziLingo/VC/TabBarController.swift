import UIKit

final class TabBarController: UITabBarController {

    private let separatorView = UIView()

    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        configureSeparator()
        delegate = self
        selectedIndex = 0
    }

    private func configureSeparator() {
        tabBar.layer.shadowColor = UIColor.black.cgColor
        tabBar.layer.shadowOpacity = 0.1
        tabBar.layer.shadowOffset = CGSize(width: 0, height: -2)
        tabBar.layer.shadowRadius = 2
        tabBar.layer.masksToBounds = false
    }

    private func configure() {
        tabBar.backgroundColor = .white
        tabBar.tintColor = CustomColors.Basic.blue
        tabBar.unselectedItemTintColor = CustomColors.Basic.ultraLiteGray

        let homeVC = UINavigationController(rootViewController: HomeViewController())
        let profileVC = UINavigationController(rootViewController: ProfileViewController())
        let statsVC = UINavigationController(rootViewController: StatsViewController())
        let settingsVC = UINavigationController(rootViewController: SettingsVC())

        homeVC.tabBarItem = UITabBarItem(title: "Home", image: UIImage(systemName: "house.fill"), tag: 0)
        profileVC.tabBarItem = UITabBarItem(title: "Profile", image: UIImage(systemName: "person.circle.fill"), tag: 1)
        statsVC.tabBarItem = UITabBarItem(title: "Stats", image: UIImage(systemName: "chart.bar.fill"), tag: 2)
        settingsVC.tabBarItem = UITabBarItem(title: "Settings", image: UIImage(systemName: "gearshape.fill"), tag: 3)

        setViewControllers([homeVC, statsVC, profileVC, settingsVC], animated: false)
    }
}

extension TabBarController: UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        return true
    }
}
