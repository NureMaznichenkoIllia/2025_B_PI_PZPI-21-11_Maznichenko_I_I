//
//  HomeViewController.swift
//  QuiziLingo
//
//  Created by m223 on 14.06.2025.
//


import UIKit

class HomeViewController: UIViewController {

    private let bottomPurpleView = UIView()
    
    private let helloLabel: UILabel = {
        let label = UILabel()
        label.text = "Hello, Illia Maznichenko"
        label.font = CustomFonts.FredokaMedium.font(size: 22)
        label.textColor = .white
        return label
    }()
    
    private let subtitleLabel: UILabel = {
        let label = UILabel()
        label.text = "What would you like to learn today?"
        label.font = CustomFonts.FredokaRegular.font(size: 16)
        label.textColor = .gray
        return label
    }()
    
    private lazy var headerStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [helloLabel, subtitleLabel])
        stack.axis = .vertical
        stack.spacing = 8
        return stack
    }()
    
    private var collectionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = CustomColors.Basic.purple65
        configureNavBar()
        setupLayout()
        setupCollectionView()
    }

    private func configureNavBar() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "person.circle"),
            style: .plain,
            target: self,
            action: #selector(profileTapped)
        )
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "bell"),
            style: .plain,
            target: self,
            action: #selector(notificationsTapped)
        )
    }

    @objc private func profileTapped() {
        print("Profile tapped")
    }

    @objc private func notificationsTapped() {
        print("Notifications tapped")
    }

    private func setupLayout() {
        bottomPurpleView.backgroundColor = CustomColors.Basic.purple65
        bottomPurpleView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomPurpleView)
        
        headerStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerStack)

        NSLayoutConstraint.activate([
            bottomPurpleView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bottomPurpleView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomPurpleView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomPurpleView.heightAnchor.constraint(equalToConstant: 40),
            
            headerStack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            headerStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            headerStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    private func setupCollectionView() {
        let layout = createCompositionalLayout()
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .white
        
        view.addSubview(collectionView)
        collectionView.dataSource = self
        collectionView.delegate = self
        
        collectionView.register(CourseCell.self, forCellWithReuseIdentifier: "CourseCell")
        collectionView.register(FeaturedCell.self, forCellWithReuseIdentifier: "FeaturedCell")
        collectionView.register(HeaderViewCellForHome.self,
                                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                                withReuseIdentifier: "HeaderViewCellForHome")
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: headerStack.bottomAnchor, constant: 16),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: bottomPurpleView.topAnchor)
        ])
    }

    private func createCompositionalLayout() -> UICollectionViewLayout {
        return UICollectionViewCompositionalLayout { sectionIndex, _ in
            if sectionIndex == 0 {

                let item = NSCollectionLayoutItem(layoutSize: NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(0.45),
                    heightDimension: .fractionalHeight(1.0)))
                item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 0)

                let group = NSCollectionLayoutGroup.horizontal(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(1.0),
                        heightDimension: .fractionalHeight(0.35)),
                    subitems: [item])

                let section = NSCollectionLayoutSection(group: group)
                section.orthogonalScrollingBehavior = .groupPaging
                section.boundarySupplementaryItems = [self.sectionHeader()]
                return section
            } else {
                let item = NSCollectionLayoutItem(layoutSize: NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1.0),
                    heightDimension: .absolute(120)))
                item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 20)

                let group = NSCollectionLayoutGroup.vertical(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(1.0),
                        heightDimension: .estimated(300)),
                    subitems: [item])

                let section = NSCollectionLayoutSection(group: group)
                section.orthogonalScrollingBehavior = .continuous
                section.boundarySupplementaryItems = [self.sectionHeader()]
                return section
            }
        }
    }

    private func sectionHeader() -> NSCollectionLayoutBoundarySupplementaryItem {
        return NSCollectionLayoutBoundarySupplementaryItem(
            layoutSize: NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(1.0),
                heightDimension: .absolute(44)),
            elementKind: UICollectionView.elementKindSectionHeader,
            alignment: .top)
    }
}

// MARK: - DataSource & Delegate
extension HomeViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func numberOfSections(in collectionView: UICollectionView) -> Int { 2 }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int { 5 }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CourseCell", for: indexPath) as! CourseCell
            
            if indexPath.row == 0 {
                let completedLessons = UserDefaults.standard.integer(forKey: "completed_english_lessons")
                cell.configure(title: "English Language", current: completedLessons, total: 20)
                cell.progressView.setProgress(current: completedLessons, total: 20)
                
            }else{
                
                cell.configure(title: "Spanish Language", current: 0, total: 20)
                cell.progressView.setProgress(current: 0, total: 20)
                cell.lessonsIcon.tintColor = UIColor.black.withAlphaComponent(0.2)
                cell.contentView.backgroundColor = CustomColors.Basic.orange253
                cell.titleLabel.textColor = CustomColors.Basic.darkLighter
                cell.lessonsLabel.textColor = CustomColors.Basic.darkGray
                cell.progressView.progressLabel.textColor = CustomColors.Basic.darkGray
                cell.progressView.trackLayer.strokeColor = UIColor.black.withAlphaComponent(0.2).cgColor

            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FeaturedCell", for: indexPath) as! FeaturedCell
            
            let albumsCount = AlbumStorage.shared.albumsCount
            cell.configure(
                title: "Albums",
                subtitle: "Add and learn new words",
                time: "\(albumsCount) albums",
                albumCount: albumsCount
            )
            return cell
        }
    }

    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(
            ofKind: kind,
            withReuseIdentifier: "HeaderViewCellForHome",
            for: indexPath) as? HeaderViewCellForHome
        if indexPath.section == 0 {
            header?.configure(title: "Learning cources")
        } else {
            header?.configure(title: "Albums & Cards")
            header?.seeAllButton.isHidden = true
        }
        return header ?? UICollectionReusableView()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            let lessonVC = LessonViewController()
            lessonVC.hidesBottomBarWhenPushed = true
            navigationController?.pushViewController(lessonVC, animated: true)
        }else{
            let cardsVC = CardsVC()
            cardsVC.hidesBottomBarWhenPushed = true
            navigationController?.pushViewController(cardsVC, animated: true)
        }
    }
}
