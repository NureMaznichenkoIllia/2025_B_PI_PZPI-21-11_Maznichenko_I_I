import UIKit

class CourseCell: UICollectionViewCell {
    let titleLabel = UILabel()
    let lessonsLabel = UILabel()
    var lessonsIcon = UIImageView()
    let lessonsInfoStack = UIStackView()
    let progressView = CircularProgressView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder: NSCoder) { fatalError() }

    private func setupView() {
        contentView.backgroundColor = CustomColors.Basic.blue
        contentView.layer.cornerRadius = 12
        contentView.clipsToBounds = true

        progressView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(progressView)
        NSLayoutConstraint.activate([
            progressView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            progressView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 25),
            progressView.widthAnchor.constraint(equalToConstant: 90),
            progressView.heightAnchor.constraint(equalTo: progressView.widthAnchor)
        ])

        titleLabel.font = CustomFonts.FredokaMedium.font(size: 18)
        titleLabel.textColor = .white
        titleLabel.numberOfLines = 2
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(titleLabel)
        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 12),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.centerXAnchor, constant: 30),
            titleLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -40)
        ])

        lessonsIcon = UIImageView(image: UIImage(systemName: "book.fill"))
        lessonsIcon.tintColor = .white
        lessonsIcon.widthAnchor.constraint(equalToConstant: 16).isActive = true
        lessonsIcon.heightAnchor.constraint(equalToConstant: 16).isActive = true

        lessonsLabel.textColor = .white
        lessonsLabel.font = CustomFonts.FredokaRegular.font(size: 13)
        lessonsLabel.text = "20 уроков"

        lessonsInfoStack.axis = .horizontal
        lessonsInfoStack.spacing = 4
        lessonsInfoStack.addArrangedSubview(lessonsIcon)
        lessonsInfoStack.addArrangedSubview(lessonsLabel)
        lessonsInfoStack.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(lessonsInfoStack)
        NSLayoutConstraint.activate([
            lessonsInfoStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 12),
            lessonsInfoStack.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10)
        ])
    }

    func configure(title: String, current: Int, total: Int) {
        titleLabel.text = title
        progressView.current = current
        progressView.total = total
        
        if let label = lessonsInfoStack.arrangedSubviews[1] as? UILabel {
            label.text = "\(total) Classes"
        }
    }
}
