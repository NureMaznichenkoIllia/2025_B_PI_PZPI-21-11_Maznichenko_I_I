import UIKit

class FeaturedCell: UICollectionViewCell {
    private let titleLabel = UILabel()
    private let subtitleLabel = UILabel()
    private let timeInfoStack = UIStackView()
    private let leftInfoStack = UIStackView()
    private let emojiImageView = UIImageView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder: NSCoder) { fatalError() }

    private func setupView() {
        contentView.backgroundColor = CustomColors.Basic.mauve
        contentView.layer.cornerRadius = 12
        contentView.clipsToBounds = true

        // Title
        titleLabel.font = CustomFonts.FredokaMedium.font(size: 18)
        titleLabel.textColor = CustomColors.Basic.darkLighter
        titleLabel.numberOfLines = 2
        titleLabel.text = "Grammar\nQuiz"

        // Subtitle
        subtitleLabel.font = CustomFonts.FredokaRegular.font(size: 14)
        subtitleLabel.textColor = CustomColors.Basic.darkGray
        subtitleLabel.text = "Business English"

        // Time Stack (icon + text)
        let timeIcon = UIImageView(image: UIImage(systemName: "folder.fill"))
        timeIcon.tintColor = CustomColors.Basic.darkGray
        timeIcon.widthAnchor.constraint(equalToConstant: 16).isActive = true
        timeIcon.heightAnchor.constraint(equalToConstant: 16).isActive = true

        let timeLabel = UILabel()
        timeLabel.font = CustomFonts.FredokaRegular.font(size: 14)
        timeLabel.textColor = CustomColors.Basic.darkGray
        timeLabel.text = "2 hour"

        timeInfoStack.axis = .horizontal
        timeInfoStack.spacing = 4
        timeInfoStack.addArrangedSubview(timeIcon)
        timeInfoStack.addArrangedSubview(timeLabel)

        // Left Stack
        leftInfoStack.axis = .vertical
        leftInfoStack.spacing = 8
        leftInfoStack.translatesAutoresizingMaskIntoConstraints = false
        leftInfoStack.addArrangedSubview(titleLabel)
        leftInfoStack.addArrangedSubview(subtitleLabel)
        leftInfoStack.addArrangedSubview(timeInfoStack)

        contentView.addSubview(leftInfoStack)
        NSLayoutConstraint.activate([
            leftInfoStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            leftInfoStack.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])

        emojiImageView.translatesAutoresizingMaskIntoConstraints = false
        emojiImageView.contentMode = .scaleAspectFit
        emojiImageView.image = emojiToImage("📚", size: 40)
        contentView.addSubview(emojiImageView)

        NSLayoutConstraint.activate([
            emojiImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            emojiImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            emojiImageView.widthAnchor.constraint(equalToConstant: 44),
            emojiImageView.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    func configure(title: String, subtitle: String, time: String, albumCount: Int) {
        titleLabel.text = title
        subtitleLabel.text = subtitle

        if let timeLabel = timeInfoStack.arrangedSubviews[1] as? UILabel {
            timeLabel.text = "\(albumCount) albums"
        }
    }

    private func emojiToImage(_ emoji: String, size: CGFloat = 50) -> UIImage? {
        let label = UILabel()
        label.text = emoji
        label.font = UIFont.systemFont(ofSize: size)
        label.textAlignment = .center
        label.backgroundColor = .clear

        let paddedSize = size * 1.1
        label.frame = CGRect(x: 0, y: 0, width: paddedSize, height: paddedSize)

        UIGraphicsBeginImageContextWithOptions(label.bounds.size, false, 0)
        guard let context = UIGraphicsGetCurrentContext() else { return nil }
        label.layer.render(in: context)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return img
    }
}
