import UIKit
import Charts

final class StatsViewController: UIViewController {
    
    private let viewModel = StatsViewModel()
    
    private let scrollView = UIScrollView()
    private let contentView = UIStackView()
    private let progressBar = UIProgressView(progressViewStyle: .default)
    private let chartView = LineChartView()
    private let statLabel = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Stats"
        view.backgroundColor = .systemBackground
        setupUI()
        bindViewModel()
    }
    
    private func setupUI() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.axis = .vertical
        contentView.spacing = 24
        contentView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 24),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: -24),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 16),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -16),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -32)
        ])
        
        let title = UILabel()
        title.text = "Your Learning Progress"
        title.font = .boldSystemFont(ofSize: 22)
        title.textAlignment = .center
        contentView.addArrangedSubview(title)
        
        progressBar.trackTintColor = .systemGray5
        progressBar.tintColor = .systemGreen
        progressBar.heightAnchor.constraint(equalToConstant: 12).isActive = true
        contentView.addArrangedSubview(progressBar)
        
        chartView.heightAnchor.constraint(equalToConstant: 300).isActive = true
        contentView.addArrangedSubview(chartView)

        statLabel.font = .systemFont(ofSize: 18)
        statLabel.numberOfLines = 0
        statLabel.textAlignment = .center
        contentView.addArrangedSubview(statLabel)
    }
    
    private func bindViewModel() {
        progressBar.setProgress(viewModel.progress, animated: false)
        chartView.data = viewModel.chartData
        
        let statText = viewModel.statItems
            .map { "\($0.title): \($0.value)" }
            .joined(separator: "\n")
        
        statLabel.text = statText
    }
}
