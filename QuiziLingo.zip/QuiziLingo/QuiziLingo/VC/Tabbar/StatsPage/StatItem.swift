//
//  StatItem.swift
//  QuiziLingo
//
//  Created by m223 on 18.06.2025.
//


import Foundation
import Charts

struct StatItem {
    let title: String
    let value: String
}

final class StatsViewModel {
    
    var progress: Float {
        0.7
    }
    
    var statItems: [StatItem] {
        [
            StatItem(title: "Words Learned", value: "128"),
            StatItem(title: "Correct Answers", value: "89%"),
            StatItem(title: "Streak", value: "🔥 12 days")
        ]
    }
    
    var chartData: LineChartData {
        let entries = (0..<7).map { ChartDataEntry(x: Double($0), y: Double(Int.random(in: 3...10))) }
        let dataSet = LineChartDataSet(entries: entries, label: "Daily Score")
        dataSet.colors = [.systemBlue]
        dataSet.circleColors = [.systemBlue]
        dataSet.circleRadius = 4
        dataSet.lineWidth = 2
        return LineChartData(dataSet: dataSet)
    }
}
