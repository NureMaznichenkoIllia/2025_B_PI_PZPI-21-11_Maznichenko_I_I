//
//  AchievementCell.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//


import UIKit

class AchievementCell: UICollectionViewCell {
    private let imageView = UIImageView()
    private let titleLabel = UILabel()
    private let levelLabel = UILabel()
    private let stackView = UIStackView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder: NSCoder) { fatalError() }

    private func setupView() {
        contentView.backgroundColor = CustomColors.Basic.white243
        contentView.layer.cornerRadius = 12
        contentView.clipsToBounds = true

        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 20
        imageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            imageView.widthAnchor.constraint(equalToConstant: 40),
            imageView.heightAnchor.constraint(equalToConstant: 40)
        ])

        titleLabel.font = CustomFonts.FredokaMedium.font(size: 14)
        titleLabel.textColor = .black
        titleLabel.textAlignment = .center

        levelLabel.font = CustomFonts.FredokaRegular.font(size: 12)
        levelLabel.textColor = .darkGray
        levelLabel.textAlignment = .center

        // Stack View
        stackView.axis = .vertical
        stackView.spacing = 8
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false

        stackView.addArrangedSubview(imageView)
        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(levelLabel)

        contentView.addSubview(stackView)
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
    }

    func configure(image: UIImage, title: String, level: String) {
        imageView.image = image
        titleLabel.text = title
        levelLabel.text = level
    }
}
