import UIKit
import FlagKit

final class ProfileViewController: UIViewController {

    // MARK: - UI Elements

    private let backgroundColoredView = UIView()
    private let backgroundWhiteView = UIView()

    private let profileImageView: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(systemName: "person.circle.fill")
        iv.tintColor = .gray
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.layer.cornerRadius = 50
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.widthAnchor.constraint(equalToConstant: 100).isActive = true
        iv.heightAnchor.constraint(equalToConstant: 100).isActive = true
        return iv
    }()

    private let nameLabel: UILabel = {
        let label = UILabel()
        label.text = "Illia Maznichenko"
        label.font = CustomFonts.FredokaMedium.font(size: 26)
        label.textColor = CustomColors.Basic.gray
        label.textAlignment = .center
        return label
    }()

    private let joinedLabel: UILabel = {
        let label = UILabel()
        label.text = "Joined June 2025"
        label.font = CustomFonts.FredokaRegular.font(size: 20)
        label.textColor = CustomColors.Basic.ultraLiteGray
        label.textAlignment = .center
        return label
    }()

    private let addLanguageButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Add language +", for: .normal)
        
        let blue = CustomColors.Basic.blue
        btn.setTitleColor(blue, for: .normal)
        
        btn.layer.borderColor = blue.cgColor
        btn.layer.borderWidth = 2
        btn.layer.cornerRadius = 10
        btn.backgroundColor = blue.withAlphaComponent(0.1)

        btn.titleLabel?.font = CustomFonts.FredokaMedium.font(size: 16)
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()


    // CollectionView for sections

    enum SectionType: Int, CaseIterable {
        case myActivity
        case achievement
    }

    private var collectionView: UICollectionView!

    private var totalHours: Int = 0

    private var selectedPeriod: String = "Week"

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Profile"
        
        backgroundColoredView.backgroundColor = CustomColors.Basic.purple65
        backgroundColoredView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(backgroundColoredView)
        backgroundWhiteView.backgroundColor = .white
        backgroundWhiteView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(backgroundWhiteView)

        NSLayoutConstraint.activate([
            backgroundColoredView.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundColoredView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            backgroundColoredView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundColoredView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        NSLayoutConstraint.activate([
            backgroundWhiteView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            backgroundWhiteView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            backgroundWhiteView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundWhiteView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        view.backgroundColor = UIColor.purple

        setupProfileStack()
        setupCollectionView()
        
        let editButton = UIBarButtonItem(
            image: UIImage(systemName: "pencil"),
            style: .plain,
            target: self,
            action: #selector(editButtonTapped)
        )
        editButton.tintColor = .white
        navigationItem.rightBarButtonItem = editButton

    }
    
    @objc private func editButtonTapped() {
        print("Edit button tapped")
    }

    private func setupProfileStack() {
        let stack = UIStackView(arrangedSubviews: [profileImageView, nameLabel, joinedLabel, addLanguageButton])
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            addLanguageButton.widthAnchor.constraint(equalToConstant: 140),
            addLanguageButton.heightAnchor.constraint(equalToConstant: 44),
        ])

        addLanguageButton.addTarget(self, action: #selector(addLanguageTapped), for: .touchUpInside)
    }

    @objc private func addLanguageTapped() {
        print("Add language button tapped")
    }

    private func setupCollectionView() {
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: createLayout())
        collectionView.backgroundColor = .clear
        collectionView.translatesAutoresizingMaskIntoConstraints = false

        collectionView.register(ActivityCell.self, forCellWithReuseIdentifier: ActivityCell.reuseId)
        collectionView.register(AchievementCell.self, forCellWithReuseIdentifier: "AchievementCell")
        collectionView.register(HeaderViewCellForHome.self,
                                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                                withReuseIdentifier: "HeaderViewCellForHome")

        collectionView.dataSource = self
        collectionView.delegate = self

        view.addSubview(collectionView)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: addLanguageButton.bottomAnchor, constant: 20),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }

    private func createLayout() -> UICollectionViewLayout {
        let layout = UICollectionViewCompositionalLayout { [weak self] sectionIndex, _ in
            guard let self = self else { return nil }
            
            let sectionType = SectionType(rawValue: sectionIndex)!

            // Header size
            let headerSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1), heightDimension: .absolute(44))
            let sectionHeader = NSCollectionLayoutBoundarySupplementaryItem(
                layoutSize: headerSize,
                elementKind: UICollectionView.elementKindSectionHeader,
                alignment: .top)

            switch sectionType {
            case .myActivity:

                let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1))
                let item = NSCollectionLayoutItem(layoutSize: itemSize)

                let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1), heightDimension: .absolute(80))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])

                let section = NSCollectionLayoutSection(group: group)
                section.boundarySupplementaryItems = [sectionHeader]
                section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 16, trailing: 20)
                return section

            case .achievement:

                let item = NSCollectionLayoutItem(layoutSize: NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(0.495),
                    heightDimension: .fractionalHeight(1.0)))
                item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 10)

                let group = NSCollectionLayoutGroup.horizontal(
                    layoutSize: NSCollectionLayoutSize(
                        widthDimension: .fractionalWidth(1.0),
                        heightDimension: .fractionalHeight(0.33)),
                    subitems: [item])

                let section = NSCollectionLayoutSection(group: group)
                section.boundarySupplementaryItems = [sectionHeader]
                section.orthogonalScrollingBehavior = .groupPaging
                return section
            }
        }
        return layout
    }
}

// MARK: - UICollectionViewDataSource

extension ProfileViewController: UICollectionViewDataSource {

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        SectionType.allCases.count
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch SectionType(rawValue: section)! {
        case .myActivity: return 1
        case .achievement: return 2
        }
    }

    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let sectionType = SectionType(rawValue: indexPath.section)!

        switch sectionType {
        case .myActivity:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ActivityCell.reuseId, for: indexPath) as! ActivityCell
            cell.configure(totalMinutes: totalHours, selectedPeriod: selectedPeriod)
            cell.periodButtonAction = { [weak self] in
                self?.showPeriodSelection()
            }
            return cell
        case .achievement:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AchievementCell", for: indexPath) as! AchievementCell

            if indexPath.row == 0 {
                let language: LanguageFlag = .english
                let flag = Flag(countryCode: language.rawValue)!
                let image = flag.image(style: FlagStyle.circle)

            cell.configure(image: image, title: language.title, level: "Level 1")
                
            }else{
                
                let language: LanguageFlag = .spanish
                let flag = Flag(countryCode: language.rawValue)!
                let image = flag.image(style: FlagStyle.circle)

            cell.configure(image: image, title: language.title, level: "Level 0")

            }

            return cell
        }
    }

    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {

        guard kind == UICollectionView.elementKindSectionHeader else {
            return UICollectionReusableView()
        }

        let header = collectionView.dequeueReusableSupplementaryView(
            ofKind: kind,
            withReuseIdentifier: "HeaderViewCellForHome",
            for: indexPath) as? HeaderViewCellForHome

        switch SectionType(rawValue: indexPath.section)! {
        case .myActivity:
            header?.configure(title: "My Activity")
            header?.seeAllButton.isHidden = true
        case .achievement:
            header?.configure(title: "Achievement")
            header?.seeAllButton.isHidden = true
        }
        return header ?? UICollectionReusableView()
    }
}

// MARK: - UICollectionViewDelegate

extension ProfileViewController: UICollectionViewDelegate {
    // Any delegate methods if needed
}

// MARK: - Period Selection

extension ProfileViewController {
    private func showPeriodSelection() {
        let alert = UIAlertController(title: "Select period", message: nil, preferredStyle: .actionSheet)
        let periods = ["Week", "Month", "Year"]

        periods.forEach { period in
            alert.addAction(UIAlertAction(title: period, style: .default, handler: { [weak self] _ in
                self?.selectedPeriod = period
                self?.collectionView.reloadSections(IndexSet(integer: SectionType.myActivity.rawValue))
            }))
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }
}

// MARK: - ActivityCell

final class ActivityCell: UICollectionViewCell {

    static let reuseId = "ActivityCell"

    private let timeImageView: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(systemName: "clock")
        iv.tintColor = .purple
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.widthAnchor.constraint(equalToConstant: 32).isActive = true
        iv.heightAnchor.constraint(equalToConstant: 32).isActive = true
        return iv
    }()

    private let totalHoursLabel: UILabel = {
        let label = UILabel()
        label.text = "Total Hours"
        label.font = .systemFont(ofSize: 14)
        label.textColor = .black
        return label
    }()

    private let totalHoursCountLabel: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.font = .boldSystemFont(ofSize: 18)
        label.textColor = .black
        return label
    }()

    private let periodButton: UIButton = {
        let btn = UIButton(type: .system)
        
        btn.setTitleColor(.gray, for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 14, weight: .medium)
        
        btn.setTitle("Week", for: .normal)
        
        btn.layer.borderColor = UIColor.systemBlue.cgColor
        btn.layer.borderWidth = 1
        btn.layer.cornerRadius = 8
        btn.contentEdgeInsets = UIEdgeInsets(top: 6, left: 12, bottom: 6, right: 30)
        
        let image = UIImage(systemName: "chevron.down")
        let imageView = UIImageView(image: image)
        imageView.tintColor = .gray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        btn.addSubview(imageView)
        
        NSLayoutConstraint.activate([
            imageView.centerYAnchor.constraint(equalTo: btn.titleLabel!.centerYAnchor),
            imageView.trailingAnchor.constraint(equalTo: btn.trailingAnchor, constant: -12),
            imageView.widthAnchor.constraint(equalToConstant: 20),
            imageView.heightAnchor.constraint(equalToConstant: 20),
        ])
        
        return btn
    }()

    var periodButtonAction: (() -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
        periodButton.addTarget(self, action: #selector(periodButtonTapped), for: .touchUpInside)
        contentView.backgroundColor = CustomColors.Basic.white243
        contentView.layer.cornerRadius = 8
    }

    @objc private func periodButtonTapped() {
        periodButtonAction?()
    }

    private func setupUI() {
        let verticalStack = UIStackView(arrangedSubviews: [totalHoursLabel, totalHoursCountLabel])
        verticalStack.axis = .vertical
        verticalStack.spacing = 4

        let hStack = UIStackView(arrangedSubviews: [timeImageView, verticalStack, periodButton])
        hStack.axis = .horizontal
        hStack.spacing = 12
        hStack.alignment = .center
        hStack.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(hStack)

        NSLayoutConstraint.activate([
            hStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 12),
            hStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -12),
            hStack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            hStack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),

            periodButton.widthAnchor.constraint(equalToConstant: 120)
        ])
    }

    func configure(totalMinutes: Int, selectedPeriod: String) {
        let hours = totalMinutes / 60
        let minutes = totalMinutes % 60
        totalHoursCountLabel.text = "\(hours)h : \(minutes) min"
        
        periodButton.setTitle(selectedPeriod, for: .normal)
    }


    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
