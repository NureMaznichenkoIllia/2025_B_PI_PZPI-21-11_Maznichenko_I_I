
import UIKit

class PPVC: UIViewController {
    
    private let scrollView = UIScrollView()
    private let contentView = UIView()
    
    private let headerLabel: UILabel = {
        let label = UILabel()
        label.text = "Policy"
        label.font = CustomFonts.InterSemiBold.font(size: 20)
        label.textAlignment = .left
//        label.textColor = CustomColors.Basic.brown30
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let introductionLabel: UILabel = {
        let label = UILabel()
        label.text = "1. Introduction"
        label.font = CustomFonts.InterSemiBold.font(size: 16)
        label.textAlignment = .left
//        label.textColor = CustomColors.Basic.brown30
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let introductionText: UILabel = {
        let label = UILabel()
        label.text = """
This Privacy Policy applies when you use any of the Apps of this publisher and should be read together with the End User License Agreement EULA. By using a Publisher’s App, you are consenting to our processing of your information in ways set out in this Privacy Policy. If you do not agree with it, please do not use any Publisher’s Apps. In certain cases, for example, if geolocation data is processed by the relevant Publisher’s App, the Publisher’s App will prompt you to give additional consent. In such case, you can choose not to give consent to us processing data related to your location but you can still use the Publisher’s App.This Privacy Policy may change so you should review it regularly. We will notify you of any material changes in the way we treat your information through the Publisher’s Apps you use.
"""
        label.font = CustomFonts.InterMedium.font(size: 13)
//        label.textColor = CustomColors.Basic.gray184
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let dataCollectLabel: UILabel = {
        let label = UILabel()
        label.text = "2. Data we collect"
        label.font = CustomFonts.InterSemiBold.font(size: 16)
        label.textAlignment = .left
//        label.textColor = CustomColors.Basic.brown30
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let dataCollectText: UILabel = {
        let label = UILabel()
        label.text = """
When you use an Publisher’s App, Publisher may collect data, including information which directly or indirectly identifies you. Your information may be kept in an identifiable format, or in an aggregate format which means that you cannot reasonably be identified from it. The information we collect about you includes:
If an Publisher’s App offers you the option to register, we will collect the information you provide to us in the registration form. This may include identification data such as your name, email address or other account or registration information.We will also collect your information when you use Publisher’s Apps such as when you post or share material, upload data, request further services or make selections using the Publisher’s Apps, if such functionality is available in the Publisher’s App.We will collect information about you when you interact with us such as when you report a problem, contact or communicate with us.We may collect certain device information and electronic identifiers such as your mobile device identifier provided by your mobile device operating system, your mobile operating system details and the name of your mobile carrier. For example, if you use the iOS platform then Advertiser IDs (also known as “IDFAs”) may be collected. Other identifiers collected may include IP addresses, OpenUDID, Session ID, ODIn1, iOS Vendor IDs, MAC addresses, IMEI, Android ID for Android platform, and ODIN1 for OS X (together with the IDFAs, the “App Identifiers”).Information about how and when you use the Publisher’s App. This includes the amount of times you used the Publisher’s App, which parts of it you viewed and other technical data such as country settings and timestamps.Geolocation data, which is any information which indicates the geographical position of your device and which may include the time the location was recorded. Before processing any precise GPS geolocation data, the Publisher’s App will require you to give your consent, which you can revoke by changing the privacy settings of your device.Any of your information you provide or permit to be provided to us via a social network or public forum provider like Facebook when you link the Publisher’s App to your social network or public forum account. This data may include your use of the Publisher’s App on such public forums and/or social networks, including with whom you share the Publisher’s App. For further information how and for what purpose the social network provider collects etc. your data see their privacy policy.We automatically collect certain information from your device when you use the Publisher’s App including information about your device, carrier and other technical data.

"""
        label.font = CustomFonts.InterMedium.font(size: 13)
//        label.textColor = CustomColors.Basic.gray184
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    private func setupUI() {
        view.backgroundColor = .white
        
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        contentView.addSubview(headerLabel)
        contentView.addSubview(introductionLabel)
        contentView.addSubview(introductionText)
        contentView.addSubview(dataCollectLabel)
        contentView.addSubview(dataCollectText)
        
        NSLayoutConstraint.activate([
            // ScrollView constraints
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            // ContentView constraints
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            
            // Header label
            headerLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16),
            headerLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            
            // Introduction section
            introductionLabel.topAnchor.constraint(equalTo: headerLabel.bottomAnchor, constant: 24),
            introductionLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            introductionLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            introductionText.topAnchor.constraint(equalTo: introductionLabel.bottomAnchor, constant: 8),
            introductionText.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            introductionText.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            // Data we collect section
            dataCollectLabel.topAnchor.constraint(equalTo: introductionText.bottomAnchor, constant: 24),
            dataCollectLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            dataCollectLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            dataCollectText.topAnchor.constraint(equalTo: dataCollectLabel.bottomAnchor, constant: 8),
            dataCollectText.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            dataCollectText.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            dataCollectText.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16)
        ])
    }
}
