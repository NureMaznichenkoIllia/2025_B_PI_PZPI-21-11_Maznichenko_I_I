import UIKit

class SettingsVC: UIViewController {

    private let backgroundView: UIView = {
        let view = UIView()
        view.backgroundColor = CustomColors.Basic.purple65
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: UIScreen.main.bounds.width - 32, height: 60)
        layout.minimumLineSpacing = 16
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.backgroundColor = .clear
        cv.register(SettingCell.self, forCellWithReuseIdentifier: SettingCell.identifier)
        return cv
    }()

    private let settingsData: [SettingItem] = [
        SettingItem(title: "Notification", hasSwitch: true),
        SettingItem(title: "Rate Us", hasSwitch: false),
        SettingItem(title: "Share App", hasSwitch: false),
        SettingItem(title: "Terms of Service", hasSwitch: false),
        SettingItem(title: "Privacy Policy", hasSwitch: false),
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Settings"
        view.backgroundColor = .white
        setupLayout()
    }

    private func setupLayout() {
        view.addSubview(backgroundView)
        view.addSubview(containerView)
        containerView.addSubview(collectionView)

        collectionView.delegate = self
        collectionView.dataSource = self

        NSLayoutConstraint.activate([
            backgroundView.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            backgroundView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            containerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            containerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            containerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            containerView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            collectionView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 10),
            collectionView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor)
        ])
    }
}

// MARK: - UICollectionViewDelegate / DataSource
extension SettingsVC: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ cv: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return settingsData.count
    }

    func collectionView(_ cv: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = settingsData[indexPath.item]
        let cell = cv.dequeueReusableCell(withReuseIdentifier: SettingCell.identifier, for: indexPath) as! SettingCell
        cell.configure(with: item)
        return cell
    }
}

// MARK: - Models
struct SettingItem {
    let title: String
    let hasSwitch: Bool
}

// MARK: - Cell
class SettingCell: UICollectionViewCell {
    static let identifier = "SettingCell"

    private let titleLabel = UILabel()
    private let toggleSwitch = UISwitch()
    private let arrowImage = UIImageView(image: UIImage(systemName: "chevron.right"))

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = CustomColors.Basic.white243
        contentView.layer.cornerRadius = 12
        contentView.clipsToBounds = true

        titleLabel.font = CustomFonts.FredokaMedium.font(size: 16)
        titleLabel.textColor = CustomColors.Basic.darkLighter
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        toggleSwitch.translatesAutoresizingMaskIntoConstraints = false
        toggleSwitch.onTintColor = CustomColors.Basic.blue
        arrowImage.tintColor = .gray
        arrowImage.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(titleLabel)
        contentView.addSubview(toggleSwitch)
        contentView.addSubview(arrowImage)

        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            titleLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),

            toggleSwitch.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            toggleSwitch.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),

            arrowImage.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            arrowImage.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
    }

    required init?(coder: NSCoder) { fatalError() }

    func configure(with item: SettingItem) {
        titleLabel.text = item.title
        toggleSwitch.isHidden = !item.hasSwitch
        arrowImage.isHidden = item.hasSwitch
    }
}
