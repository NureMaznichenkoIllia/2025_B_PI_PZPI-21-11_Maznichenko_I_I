//
//  AccountSetupVC.swift
//  QuiziLingo
//
//  Created by m223 on 10.05.2025.
//

import UIKit
import FlagKit

class AccountSetupVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    private var steps: [SetupStep] = []
    private var currentStepIndex = 0
    
    private let titleLabel = UILabel()
    private var collectionView: UICollectionView!
    private let nextButton = UIButton(type: .system)
    private let purpleBackgroundView = UIView()
    
    private var selectedIndices: [Int?] = []

    private var languages: [LanguageOption] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupPurpleBackground()
//        setupCustomBackButton()
        navigationItem.hidesBackButton = true
        setupTitleLabel()
        setupCollectionView()
        setupNextButton()
        setupSteps()

    }
    
    private func setupCustomTitle(_ text: String) {
        let titleLabel = UILabel()
        titleLabel.text = text
        titleLabel.font = CustomFonts.FredokaMedium.font(size: 17)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        
        navigationItem.titleView = titleLabel
    }
    
    private func setupSteps() {
        steps = [
            SetupStep(
                title: "What Language you want to lear?",
                options: [
                    LanguageOption(image: {
                        let language = LanguageFlag.ukrainian
                        let flag = Flag(countryCode: language.rawValue)!
                        return flag.image(style: FlagStyle.circle)
                    }(), languageName: "Ukraine"),
                    
                    LanguageOption(image: {
                        let language = LanguageFlag.english
                        let flag = Flag(countryCode: language.rawValue)!
                        return flag.image(style: FlagStyle.circle)
                    }(), languageName: "English"),

                    LanguageOption(image: {
                        let language = LanguageFlag.german
                        let flag = Flag(countryCode: language.rawValue)!
                        return flag.image(style: FlagStyle.circle)
                    }(), languageName: "German"),

                    LanguageOption(image: {
                        let language = LanguageFlag.spanish
                        let flag = Flag(countryCode: language.rawValue)!
                        return flag.image(style: FlagStyle.circle)
                    }(), languageName: "Spanish"),
                ]
            ),
            SetupStep(
                title: "What is the Main Reason To Learn English?",
                options: [
                    LanguageOption(image: emojiToImage("💼"), languageName: "For Work"),
                    LanguageOption(image: emojiToImage("✈️"), languageName: "For Travel"),
                    LanguageOption(image: emojiToImage("🏫"), languageName: "For School"),
                    LanguageOption(image: emojiToImage("👪"), languageName: "For Family"),
                    LanguageOption(image: emojiToImage("🎉"), languageName: "Just for Fun")
                ]
            ),
            SetupStep(
                title: "How much you know about English?",
                options: [
                    LanguageOption(image: emojiToImage("🌱"), languageName: "Beginner"),
                    LanguageOption(image: emojiToImage("📚"), languageName: "Basic"),
                    LanguageOption(image: emojiToImage("🧠"), languageName: "Intermediate"),
                    LanguageOption(image: emojiToImage("🚀"), languageName: "Advanced")
                ]
            ),
            SetupStep(
                title: "How old are you?",
                options: [
                    LanguageOption(image: emojiToImage("👶"), languageName: "Under 13"),
                    LanguageOption(image: emojiToImage("🧑‍🎓"), languageName: "13-18"),
                    LanguageOption(image: emojiToImage("🧑‍💼"), languageName: "19-25"),
                    LanguageOption(image: emojiToImage("🧔"), languageName: "26-40"),
                    LanguageOption(image: emojiToImage("👴"), languageName: "40+")
                ]
            ),
            SetupStep(
                title: "How much time can you spend?",
                options: [
                    LanguageOption(image: emojiToImage("🕒"), languageName: "15 min/day"),
                    LanguageOption(image: emojiToImage("⏰"), languageName: "30 min/day"),
                    LanguageOption(image: emojiToImage("🕰"), languageName: "1 hour/day"),
                    LanguageOption(image: emojiToImage("♾"), languageName: "No limit")
                ]
            ),
            SetupStep(
                title: "Where did you hear about us?",
                options: [
                    LanguageOption(image: emojiToImage("📱"), languageName: "Social Media"),
                    LanguageOption(image: emojiToImage("👫"), languageName: "Friend Recommendation"),
                    LanguageOption(image: emojiToImage("📢"), languageName: "Online Ads"),
                    LanguageOption(image: emojiToImage("🏬"), languageName: "App Store"),
                    LanguageOption(image: emojiToImage("❓"), languageName: "Other")
                ]
            )
        ]
        
        selectedIndices = Array(repeating: nil, count: steps.count)
        
        updateUIForCurrentStep()
    }

    
    @objc private func nextTapped() {
        if currentStepIndex == steps.count - 1 {
            let vc = CongratulationsVC()
            navigationController?.pushViewController(vc, animated: true)
            return
        }
        
        currentStepIndex += 1
        updateUIForCurrentStep()
    }

    private func updateUIForCurrentStep() {
        let step = steps[currentStepIndex]
        titleLabel.text = step.title
        languages = step.options
        
        // Обновляем заголовок в navigationBar
        setupCustomTitle("Completed \(currentStepIndex + 1)/\(steps.count)")
        
        collectionView.reloadData()
        
        // Восстанавливаем выделение, если ранее выбирали
        if let selectedIndex = selectedIndices[currentStepIndex] {
            let indexPath = IndexPath(item: selectedIndex, section: 0)
            collectionView.selectItem(at: indexPath, animated: false, scrollPosition: [])
            if let cell = collectionView.cellForItem(at: indexPath) as? LanguageCell {
                cell.setSelected(true)
            }
            nextButton.isEnabled = true
            nextButton.alpha = 1.0
        } else {
            // Если ничего не выбрано, кнопка Next неактивна
            nextButton.isEnabled = false
            nextButton.alpha = 0.5
        }
    }

    
    private func setupCustomBackButton() {
        let backButton = UIButton(type: .system)

        let image = UIImage(named: "back_button")?.withRenderingMode(.alwaysOriginal)
        backButton.setImage(image, for: .normal)

        backButton.addTarget(self, action: #selector(customBackTapped), for: .touchUpInside)

        let customItem = UIBarButtonItem(customView: backButton)
        navigationItem.leftBarButtonItem = customItem
    }
    
    private func setupPurpleBackground() {
        purpleBackgroundView.backgroundColor = CustomColors.Basic.purple65
        purpleBackgroundView.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(purpleBackgroundView, at: 0)

        NSLayoutConstraint.activate([
            purpleBackgroundView.topAnchor.constraint(equalTo: view.topAnchor),
            purpleBackgroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            purpleBackgroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            purpleBackgroundView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
        ])
    }

    private func setupTitleLabel() {
        titleLabel.font = CustomFonts.FredokaMedium.font(size: 22)
        titleLabel.textAlignment = .center
        titleLabel.numberOfLines = 0
        titleLabel.lineBreakMode = .byWordWrapping
        titleLabel.textColor = CustomColors.Basic.darkLighter
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(titleLabel)

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 24),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }
    
    private func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 16
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 100, right: 16)

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.allowsMultipleSelection = false
        collectionView.register(LanguageCell.self, forCellWithReuseIdentifier: LanguageCell.identifier)
        collectionView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(collectionView)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 16),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    private func setupNextButton() {
        nextButton.setBackgroundImage(UIImage(named: "next_button"), for: .normal)
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        nextButton.addTarget(self, action: #selector(nextTapped), for: .touchUpInside)
        nextButton.isEnabled = false
        nextButton.alpha = 0.5
        view.addSubview(nextButton)

        NSLayoutConstraint.activate([
            nextButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            nextButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12),
            nextButton.heightAnchor.constraint(equalToConstant: 54)
        ])
    }


    // MARK: - UICollectionView

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return languages.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LanguageCell.identifier, for: indexPath) as! LanguageCell
        cell.configure(with: languages[indexPath.item])
        
        // Отмечаем выделенный элемент при загрузке
        if selectedIndices[currentStepIndex] == indexPath.item {
            cell.setSelected(true)
        } else {
            cell.setSelected(false)
        }
        
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width - 32, height: 60)
    }
    
    @objc private func customBackTapped() {
        if currentStepIndex > 0 {
            currentStepIndex -= 1
            updateUIForCurrentStep()
        } else {
            navigationController?.popViewController(animated: true)
        }
    }
    
    private func emojiToImage(_ emoji: String, size: CGFloat = 50) -> UIImage? {
        let label = UILabel()
        label.text = emoji
        label.font = UIFont.systemFont(ofSize: size)
        label.textAlignment = .center
        label.backgroundColor = .clear
        
        let paddedSize = size * 1.1
        label.frame = CGRect(x: 0, y: 0, width: paddedSize, height: paddedSize)
        
        UIGraphicsBeginImageContextWithOptions(label.bounds.size, false, 0)
        guard let context = UIGraphicsGetCurrentContext() else { return nil }
        label.layer.render(in: context)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return img
    }

    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndices[currentStepIndex] = indexPath.item
        
        nextButton.isEnabled = true
        nextButton.alpha = 1.0
        
        collectionView.reloadData()
    }

}

struct SetupStep {
    let title: String
    let options: [LanguageOption]
}

class CongratulationsVC: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        navigationItem.hidesBackButton = true
        let imageView = UIImageView(image: UIImage(named: "congratulations_image"))
        imageView.contentMode = .scaleAspectFill
        imageView.translatesAutoresizingMaskIntoConstraints = false

        let continueButton = UIButton(type: .system)
        continueButton.setBackgroundImage(UIImage(named: "start_button"), for: .normal)
        continueButton.translatesAutoresizingMaskIntoConstraints = false
        continueButton.addTarget(self, action: #selector(continueTapped), for: .touchUpInside)

        view.addSubview(imageView)
        view.addSubview(continueButton)

        NSLayoutConstraint.activate([
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),

            continueButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            continueButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            continueButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12),
            continueButton.heightAnchor.constraint(equalToConstant: 54)
        ])
    }

    @objc private func continueTapped() {
        let newTabBarController = TabBarController()
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            if let window = scene.windows.first {
                window.rootViewController = newTabBarController
            }
        }

    }
}

