//
//  LanguageCell.swift
//  QuiziLingo
//
//  Created by m223 on 10.05.2025.
//


import UIKit

class LanguageCell: UICollectionViewCell {
    static let identifier = "LanguageCell"

    private let flagImageView = UIImageView()
    private let nameLabel = UILabel()
    private let stackView = UIStackView()

    override init(frame: CGRect) {
        super.init(frame: frame)

        flagImageView.contentMode = .scaleAspectFit
        flagImageView.widthAnchor.constraint(equalToConstant: 40).isActive = true
        flagImageView.heightAnchor.constraint(equalToConstant: 40).isActive = true
        flagImageView.clipsToBounds = true
        
        nameLabel.font = CustomFonts.FredokaMedium.font(size: 18)
        nameLabel.textColor = CustomColors.Basic.darkLighter

        stackView.axis = .horizontal
        stackView.spacing = 12
        stackView.distribution = .fillProportionally
        stackView.alignment = .center
        stackView.addArrangedSubview(flagImageView)
        stackView.addArrangedSubview(nameLabel)
        stackView.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(stackView)
        contentView.layer.cornerRadius = 12
        contentView.backgroundColor = CustomColors.Basic.white243

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            stackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -2),
            stackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(with option: LanguageOption) {
        flagImageView.image = option.image
        nameLabel.text = option.languageName
    }
    
    func setSelected(_ selected: Bool) {
        contentView.backgroundColor = selected ? CustomColors.Basic.green81 : CustomColors.Basic.white243
    }
}
