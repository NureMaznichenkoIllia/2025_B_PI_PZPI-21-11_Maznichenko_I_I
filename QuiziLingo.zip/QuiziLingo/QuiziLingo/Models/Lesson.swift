//
//  Lesson.swift
//  QuiziLingo
//
//  Created by m223 on 18.06.2025.
//


struct Lesson: Decodable {
    let objectId: String
    let title: String
    let level: String
    let duration: Int // in minutes
}