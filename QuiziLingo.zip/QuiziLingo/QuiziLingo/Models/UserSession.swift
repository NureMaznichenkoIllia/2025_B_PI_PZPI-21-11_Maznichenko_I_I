//
//  UserSession.swift
//  QuiziLingo
//
//  Created by m223 on 18.06.2025.
//


struct UserSession: Decodable {
    let objectId: String
    let sessionToken: String
    let username: String
}