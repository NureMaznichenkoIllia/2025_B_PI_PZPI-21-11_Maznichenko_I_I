//
//  LessonResponse.swift
//  QuiziLingo
//
//  Created by m223 on 18.06.2025.
//


struct LessonResponse: Decodable {
    let results: [Lesson]
}