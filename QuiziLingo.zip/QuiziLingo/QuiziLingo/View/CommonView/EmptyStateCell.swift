//
//  EmptyStateCell.swift
//  QuiziLingo
//
//  Created by m223 on 17.06.2025.
//

import UIKit

class EmptyStateCell: UICollectionViewCell {
    static let identifier = "EmptyStateCell"

    private let label: UILabel = {
        let label = UILabel()
        label.text = "No albums yet.\nTap + to add your first one!"
        label.numberOfLines = 0
        label.textAlignment = .center
        label.textColor = CustomColors.Basic.darkLighter
        label.font = CustomFonts.FredokaMedium.font(size: 20)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(label)
        contentView.backgroundColor = .clear
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            label.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
