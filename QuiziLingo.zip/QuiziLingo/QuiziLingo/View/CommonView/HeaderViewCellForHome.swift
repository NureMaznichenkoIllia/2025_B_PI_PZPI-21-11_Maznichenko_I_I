//
//  HeaderViewCellForHome.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//
import UIKit

class HeaderViewCellForHome: UICollectionReusableView {
    private let label = UILabel()
    let seeAllButton = UIButton(type: .system)

    override init(frame: CGRect) {
        super.init(frame: frame)
        label.font = CustomFonts.FredokaMedium.font(size: 22)
        label.textColor = CustomColors.Basic.darkLighter
        
        seeAllButton.setTitle("See all", for: .normal)
        seeAllButton.setTitleColor(CustomColors.Basic.darkGray, for: .normal)
        seeAllButton.titleLabel?.font = CustomFonts.FredokaRegular.font(size: 15)
        
        let stack = UIStackView(arrangedSubviews: [label, seeAllButton])
        stack.axis = .horizontal
        stack.distribution = .equalSpacing
        stack.translatesAutoresizingMaskIntoConstraints = false

        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            stack.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }

    required init?(coder: NSCoder) { fatalError() }

    func configure(title: String) {
        label.text = title
    }
}
