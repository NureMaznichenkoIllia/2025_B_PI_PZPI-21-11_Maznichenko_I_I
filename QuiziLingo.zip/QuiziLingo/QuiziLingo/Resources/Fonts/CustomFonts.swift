//
//  CustomFonts.swift
//  T-Fin
//
//  Created by m223 on 16.10.2024.
//

import UIKit
import Foundation

enum CustomFonts: String {
    
    case InterSemiBold = "Inter-SemiBold"
    case InterBold = "Inter-Bold"
    case InterRegular = "Inter-Regular"
    case InterMedium = "Inter-Medium"
    case FredokaMedium = "Fredoka-Medium"
    case FredokaRegular = "Fredoka-Regular"
    
    func font(size: CGFloat) -> UIFont {
        guard let font = UIFont(name: self.rawValue, size: size) else {
            print("Font \(self.rawValue) not found")
            return UIFont.systemFont(ofSize: size)
        }
        return font
    }
}
