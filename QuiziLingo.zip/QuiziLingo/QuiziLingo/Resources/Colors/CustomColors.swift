//
//  CustomColors.swift
//  T-Fin
//
//  Created by m223 on 16.10.2024.
//

import UIKit

enum CustomColors {
    
    enum Basic {

        //for my app
        static let purple65 = UIColor(red: 65/255, green: 15/255, blue: 163/255, alpha: 1.0)
        static let gray05 = UIColor(red: 8/255, green: 14/255, blue: 30/255, alpha: 0.05)
        static let gray = UIColor(red: 8/255, green: 14/255, blue: 30/255, alpha: 1)
        static let darkLighter = UIColor(red: 54/255, green: 59/255, blue: 68/255, alpha: 1.0)
        static let mauve = UIColor(red: 224/255, green: 245/255, blue: 254/255, alpha: 1.0)
        static let blue = UIColor(red: 98/255, green: 122/255, blue: 246/255, alpha: 1.0)
        static let ultraLiteGray = UIColor(red: 157/255, green: 159/255, blue: 164/255, alpha: 1.0)
        static let darkGray = UIColor(hex: "656872")
        
        static let white243 = UIColor(red: 243/255, green: 243/255, blue: 243/255, alpha: 1.0)
        static let orange253 = UIColor(red: 253/255, green: 246/255, blue: 236/255, alpha: 1.0)
        static let orange251 = UIColor(red: 253/255, green: 235/255, blue: 213/255, alpha: 1.0)
        static let green81 = UIColor(red: 81/255, green: 178/255, blue: 173/255, alpha: 1.0)

        
        
    }
    
}

extension UIColor {
    convenience init?(hex: String) {
        var cleanedHex = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if cleanedHex.hasPrefix("#") {
            cleanedHex.removeFirst()
        }

        guard cleanedHex.count == 6,
              let rgbValue = UInt32(cleanedHex, radix: 16) else {
            return nil
        }

        let red = CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0
        let green = CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0
        let blue = CGFloat(rgbValue & 0x0000FF) / 255.0

        self.init(red: red, green: green, blue: blue, alpha: 1.0)
    }
}

