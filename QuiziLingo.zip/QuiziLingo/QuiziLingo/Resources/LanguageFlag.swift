//
//  LanguageFlag.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//


import Foundation
import UIKit

enum LanguageFlag: String, CaseIterable {
    case german = "DE"
    case french = "FR"
    case spanish = "ES"
    case italian = "IT"
    case english = "US"
    case japanese = "JP"
    case ukrainian = "UA"

    var title: String {
        switch self {
        case .german: return "German Language"
        case .french: return "French Language"
        case .spanish: return "Spanish Language"
        case .italian: return "Italian Language"
        case .english: return "English Language"
        case .japanese: return "Japanese Language"
        case .ukrainian: return "Ukrainian Language"
        }
    }

    var level: String {
        return "Level 1"
    }
}


struct LanguageOption {
    let image: UIImage?
    let languageName: String
    
    // Вспомогательный инициализатор для вариантов с именем картинки из ассетов
    init(imageName: String, languageName: String) {
        self.image = UIImage(named: imageName)
        self.languageName = languageName
    }
    
    // Инициализатор для UIImage напрямую
    init(image: UIImage?, languageName: String) {
        self.image = image
        self.languageName = languageName
    }
}
