//
//  CircularProgressView.swift
//  QuiziLingo
//
//  Created by m223 on 15.06.2025.
//

import UIKit

class CircularProgressView: UIView {
    let trackLayer = CAShapeLayer()
    let progressLayer = CAShapeLayer()
    let progressLabel = UILabel()

    var current: Int = 0 {
        didSet { updateText() }
    }

    var total: Int = 1 {
        didSet { updateText() }
    }

    var progressColor: UIColor = .white {
        didSet { progressLayer.strokeColor = progressColor.cgColor }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        setupLayers()
        setupLabel()
    }

    required init?(coder: NSCoder) { fatalError() }

    private func setupLayers() {
        let circlePath = UIBezierPath(ovalIn: bounds)

        trackLayer.path = circlePath.cgPath
        trackLayer.strokeColor = UIColor.white.withAlphaComponent(0.2).cgColor
        trackLayer.fillColor = UIColor.clear.cgColor
        trackLayer.lineWidth = 6

        progressLayer.path = circlePath.cgPath
        progressLayer.strokeColor = progressColor.cgColor
        progressLayer.fillColor = UIColor.clear.cgColor
        progressLayer.lineWidth = 6
        progressLayer.lineCap = .round
        progressLayer.strokeEnd = 0

        layer.addSublayer(trackLayer)
        layer.addSublayer(progressLayer)
    }

    private func setupLabel() {
        progressLabel.font = CustomFonts.FredokaMedium.font(size: 18)
        progressLabel.textColor = .white
        progressLabel.textAlignment = .center
        progressLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(progressLabel)

        NSLayoutConstraint.activate([
            progressLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            progressLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }

    private func updateText() {
        progressLabel.text = "\(current)/\(total)"
    }

    func setProgress(current: Int, total: Int, animated: Bool = true) {
        self.current = current
        self.total = total

        let progressValue = CGFloat(current) / CGFloat(max(total, 1))
        if animated {
            let animation = CABasicAnimation(keyPath: "strokeEnd")
            animation.fromValue = progressLayer.strokeEnd
            animation.toValue = progressValue
            animation.duration = 0.5
            progressLayer.strokeEnd = progressValue
            progressLayer.add(animation, forKey: "progressAnim")
        } else {
            progressLayer.strokeEnd = progressValue
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let circlePath = UIBezierPath(ovalIn: bounds)
        trackLayer.path = circlePath.cgPath
        progressLayer.path = circlePath.cgPath
    }
}

